import { format, delay } from 'roadhog-api-doc';
// 是否禁用代理
const noProxy = process.env.NO_PROXY === 'true';

// 代码中会兼容本地 service mock 以及部署站点的静态数据
const proxy = {
  // 支持值为 Object 和 Array
  'GET /sso/api/currentUser': {
    $desc: "获取当前用户接口",
    $params: {
      pageSize: {
        desc: '分页',
        exp: 2,
      },
    },
    $body: {
      code: 200,
      user: {
        name: '管理员',
        avatar: '/static/images/male.png',
        id: '00000001',
        notifyCount: 12,
      }

    },


  },
  'POST /sso/api/login': (req, res) => {
    const { password, username } = req.body;
    res.send({ code: password === '123456' && username === 'admin' ? 200 : 403, type: 'account', token: '1234567890' });
  },
  'GET /sso/api/nav': {
    $desc: "获取当前用户菜单接口",
    $params: {
      pageSize: {
        desc: '分页',
        exp: 2,
      },
    },
    $body: {
      code: 200,
      menuList: [
        {
          "id": "402882825f0a53b9015f0a559baa0003",
          "parentId": null,
          "parentName": "",
          "name": "原形应用",
          "url": "/",
          "path": "/",
          "perms": null,
          "type": null,
          "icon": null,
          "orderNum": null
        },

        {
          "id": "402882825f0a53b9015f0a56f69c0005",
          "parentId": "402882825f0a53b9015f0a559baa0003",
          "parentName": "",
          "name": "控制台",
          "url": "/admin/dashboard/",
          "path": "",
          "perms": null,
          "type": null,
          "icon": "plus",
          "orderNum": null
        },


        {
          "id": "402889105f37c22c015f48422309000a",
          "parentId": "402882825f0a53b9015f0a56f69c0005",
          "parentName": null,
          "name": "菜单管理",
          "url": "/admin/menus",
          "perms": "*",
          "type": null,
          "icon": "plus",
          "orderNum": null
        },
        {
          "id": "402889105f4d0c73015f4d0dbc1d0000",
          "parentId": "402882825f0a53b9015f0a56f69c0005",
          "parentName": null,
          "name": "组织管理",
          "url": "/admin/domains",
          "type": null,
          "icon": "appstore",
          "orderNum": null
        },
        {
          "id": "402889105f4d0c73015f4d0ed89c0004",
          "parentId": "402882825f0a53b9015f0a56f69c0005",
          "parentName": null,
          "name": "角色管理",
          "url": "/admin/roles",
          "type": null,
          "icon": "trademark",
          "orderNum": null
        },
        {
          "id": "402889105f4d0c73015f4d1b04940005",
          "parentId": "402882825f0a53b9015f0a56f69c0005",
          "parentName": null,
          "name": "用户管理",
          "url": "/admin/users",
          "type": null,
          "icon": "user-add",
          "orderNum": null
        },
        {
          "id": "402889105f524a8e015f5288c5900000",
          "parentId": "402882825f0a53b9015f0a56f69c0005",
          "parentName": null,
          "name": "外链测试",
          "url": "/gs1/index.html",
          "perms": null,
          "type": null,
          "icon": "plus",
          "orderNum": null
        },

      ]
    }
  }
};
export default noProxy ? {} : delay(proxy, 1000);

