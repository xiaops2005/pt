### 环境准备
``` bash
npm install -g nrm --registry https://registry.npm.taobao.org
nrm add nexus http://192.168.1.42:8081/repository/npm/
nrm use nexus

git clone http://gitlab.viewhighcloud.com/portal/website.git
cd website
npm install
```

### 功能集成

首先注入 reducer，修改 src/index.js
``` javascript
const app = dva({
  extraReducers:{
    admin:adminReducer,
    //在这里注册你自己的reducers
  },
  onAction: thunk,
  onError (error) {
    console.log(error);
  },
});
```

然后添加页面路由，修改 src/common/nav.js

``` javascript
 component: BasicLayout,
    layout: 'BasicLayout',
    name: '首页', // for breadcrumb
    path: '/',
    children: [
      //在这里加入你自己的页面路由
    ]
```

默认开启了 mockjs，连调后台 api 需要注意几点，
1. 修改 src/index.ejs

``` html
<script>
    window.REACT_APP_CONFIG = {
      // api: 'http://127.0.0.1:8080/site',
      api: '',
    }
</script>
```
2. 修改 .roadhogrc.js

``` javascript
export default {
  "entry": "src/index.js",
  // 打开 proxy.
  "proxy": {
    "/api": {
      "target": "http://127.0.0.1:8080/site/api/",
      "changeOrigin": true,
      "pathRewrite": { "^/api": "" }
    }
  },
}  
```


## 分支修改
最好是将此项目 fork 到你自己的项目分支，然后将本项目添加到你的项目的上游分支列表中

``` bash
git remote add upstream http://gitlab.viewhighcloud.com/portal/website.git
```

更新上游分支，

``` bash
git fetch upstream
```

合并两个版本的代码

``` bash
git merge upstream/master
```
