/**
 * Created by Bojc on 2017/7/7.
 */

export const Demo_Supplier_InitData='Demo_Supplier_LoadedData';
export const Demo_Supplier_SearchData='Demo_Supplier_SearchData';
export const Demo_Supplier_SetFilter='Demo_Supplier_SetFilter';

export const Demo_ManagerSelfSer_prePage='Demo_ManagerSelfSer_prePage';
export const Demo_ManagerSelfSer_afterPage='Demo_ManagerSelfSer_afterPage';
export const Demo_ManagerSelfSer_AsucuessApi='Demo_ManagerSelfSer_AsucuessApi';

export const Demo_USER_QUERY='Demo_USER_QUERY';
export const changeInfo='changeInfo';
