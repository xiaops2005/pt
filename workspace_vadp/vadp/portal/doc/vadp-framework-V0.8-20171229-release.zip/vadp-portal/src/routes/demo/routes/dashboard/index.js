import React, { Component } from 'react';
import { Progress } from 'vadp-ui';
import {connect} from 'react-redux';
class Dashboard extends Component {
  render() {
    return (
      <div className="animated fadeIn">
          ffff
      </div>
    )
  }
}
const mapStateToProps = (state, ownProps) => ({
  auth: state.auth,
});
export default connect(mapStateToProps)(Dashboard);
