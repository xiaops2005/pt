import React, { Component } from 'react';
import { connect } from 'dva';
import { Row, Col, Card } from 'vadp-ui';
import ReactEcharts from 'echarts-for-react';
import styles from './IndexPage.css';

class IndexPage extends Component {
  state = {
    theme: 'vintage',
  }
  getOption = () => {
    const option = {
      renderer: 'svg',
      title: {
        text: '阶梯瀑布图',

      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
          type: 'shadow',        // 默认为直线，可选为：'line' | 'shadow'
        },
      },
      legend: {
        data: ['支出', '收入'],
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        splitLine: { show: false },
        data: ['11月1日', '11月2日', '11月3日', '11月4日', '11月5日', '11月6日', '11月7日', '11月8日', '11月9日', '11月10日', '11月11日'],
      },
      yAxis: {
        type: 'value',
      },
      series: [
        {
          name: '辅助',
          type: 'bar',
          stack: '总量',
          itemStyle: {
            normal: {
              barBorderColor: 'rgba(0,0,0,0)',
              color: 'rgba(0,0,0,0)',
            },
            emphasis: {
              barBorderColor: 'rgba(0,0,0,0)',
              color: 'rgba(0,0,0,0)',
            },
          },
          data: [0, 900, 1245, 1530, 1376, 1376, 1511, 1689, 1856, 1495, 1292],
        },
        {
          name: '收入',
          type: 'bar',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'top',
            },
          },
          data: [900, 345, 393, '-', '-', 135, 178, 286, '-', '-', '-'],
        },
        {
          name: '支出',
          type: 'bar',
          stack: '总量',
          label: {
            normal: {
              show: true,
              position: 'bottom',
            },
          },
          data: ['-', '-', '-', 108, 154, '-', '-', '-', 119, 361, 203],
        },
      ],
    };

    echarts.registerTheme('my_theme', {
      backgroundColor: '#f4cccc',
    });
    return option;
  }

  render() {
    const { match } = this.props;
    return (
      <div className={styles.normal}>
        <Row>
          <Col>
            <Card>
              <h3>ID: {match.params.id}</h3>
            </Card>
          </Col>
          <Col>
            <Card>
              <ReactEcharts
                option={this.getOption()}
                theme="dark"
              />
            </Card>
          </Col>
          <Col>
            <Card>
              <ReactEcharts
                option={this.getOption()}
                theme="vintage"
              />
            </Card>
          </Col>
          <Col>
            <Card>
              <ReactEcharts
                option={this.getOption()}
                theme="macarons"
              />
            </Card>
          </Col>
          <Col>
            <Card>
              <ReactEcharts
                option={this.getOption()}
                theme="my_theme"
              />
            </Card>
          </Col>
        </Row>


      </div>
    );
  }
}

IndexPage.propTypes = {
};

export default connect()(IndexPage);
