// import { message } from 'vadp-ui';
import dva from 'dva';
import thunk from 'redux-thunk';
import { models } from 'vadp-layouts';
import { reducers as adminReducer } from 'vadp-portal-admin';
import './polyfill';
import router from './router';

import SupplierReducer from './routes/demo/models/reducers/supplier';
import UserReducer from './routes/demo/models/reducers/userFormReducer';
import ManagerReducer from './routes/demo/models/reducers/managerSelfSer';
import AccountReducer from './routes/demo/models/reducers/SettingsAccount';
import QueryReducer from './routes/demo/models/reducers/query';

// 1. Initialize
const app = dva({
  extraReducers: {
    admin: adminReducer,
    supplier:SupplierReducer,
    userReducer:UserReducer,
    managerSelfSer:ManagerReducer,
    account:AccountReducer,
    query:QueryReducer,
  },
  onAction: thunk,
  onError(error) {
    console.log(error);
  },
});

// 2. Plugins
// app.use({});

// 3. Model
models.forEach((m) => {
  app.model(m);
});

// 4. Router
app.router(router);

// 5. Start
app.start('#root');

