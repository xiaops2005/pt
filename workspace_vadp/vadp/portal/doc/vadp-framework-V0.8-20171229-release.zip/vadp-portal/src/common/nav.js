
import { UserLayout, BasicLayout, Login } from 'vadp-layouts';

import { DomainPage, UserPage, RolePage, MenuPage } from 'vadp-portal-admin';
import UI from '~/routes/IndexPage';

import Dashboard from '../routes/demo/routes/dashboard/';
import LeaderManagerViewer from '../routes/demo/routes/leader/components/LeaderManagerViewer';
import MangeSelf from '../routes/demo/routes/mangeSelf/components/ManagerSelfSerViewer';
import Supplier from '../routes/demo/routes/supplier/components/SupplierViewer';
import Tree from '../routes/demo/routes/tree/TreeDemo';
import account from '../routes/demo/routes/account/components/accountViewer';
import uploadViewer from '../routes/demo/routes/upload/components/uploadViewer';
import UserManagerViewer from '../routes/demo/routes/user/components/UserManagerViewer';
import formViewer from '../routes/demo/routes/form/components/formViewer';
// import modalView from '../routes/modalDemo/components/modalView';

// nav data
export const getNavData = () => [
  {
    component: BasicLayout,
    layout: 'BasicLayout',
    name: '首页', // for breadcrumb
    path: '/',
    children: [
      {
        name: '管理控制台',
        icon: 'appstore',
        path: 'admin',
        children: [
          {
            name: 'demo1',
            path: 'demo1',
            extra: true,
            component: UI,
          },
          {
            name: 'demo2',
            path: 'demo1/:id',
            extra: false,
            component: UI,
          },
          {
            name: '组织机构',
            path: 'domain',
            component: DomainPage,
          },
          {
            name: '用户',
            path: 'user',
            component: UserPage,
          },
          {
            name: '角色',
            path: 'role',
            component: RolePage,
          },
          {
            name: '菜单',
            path: 'menu',
            component: MenuPage,
          },
        ],
      },
      {
        name: '平台Demo',
        icon: 'appstore',
        path: 'demo',
        children: [
          {
            path: '/demo/account',
            name: '我的报销单',
            component: account,
          },
          {
            path: '/demo/leader',
            name: '领导自助',
            component: LeaderManagerViewer,
          },
          {
            path: '/demo/mangeSelf',
            name: '经理自助',
            component: MangeSelf,
          },
          {
            path: '/demo/supplier',
            name: '供应商',
            component: Supplier,
          },
          {
            path: '/demo/tree',
            name: '树样例',
            component: Tree,
          },
          {
            path: '/demo/user',
            name: '员工信息管理',
            component: UserManagerViewer,
          },
          {
            path: '/demo/upload',
            name: '上传下载',
            component: uploadViewer,
          },
          {
            path: '/demo/formViewer',
            name: '表单样例',
            component: formViewer,
          },
        ],
      },
    ],
  },
  {
    component: UserLayout,
    path: '/user',
    layout: 'UserLayout',
    children: [
      {
        name: '帐户',
        icon: 'user',
        path: 'user',
        children: [
          {
            name: '登录',
            path: 'login',
            component: Login,
          },

        ],
      },
    ],
  },
];
