const  AccountConfig = {

  documentModel : {
    id:null,
    name:'',
    applyDate:new Date(),
    userName:null,
    reimbursementAmount:'0.00',
    writeDownAmount:'0.00',
    amount:'0.00',
    remark:'',
    details:[],
    userId:null,
    deptId:null,
    matter:'',
    user:[]
  },
  left : {
    array : []
  }
}

export default AccountConfig;
