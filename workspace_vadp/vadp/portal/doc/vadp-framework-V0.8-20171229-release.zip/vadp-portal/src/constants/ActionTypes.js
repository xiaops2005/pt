/***
 * for settings
 * @type {string}
 */

export const TOGGLE_COLLAPSED_SIDEBAR = 'settings.TOGGLE_COLLAPSED_SIDEBAR';
export const TOGGLE_HIDE_ASIDE = 'settings.TOGGLE_HIDE_ASIDE';
export const CHANGE_COLOR_OPTION = 'settings.CHANGE_COLOR_OPTION';


/***
 * for auth
 */

export const AUTHENTICATION_REQUEST = 'AUTHENTICATION_REQUEST';
export const AUTHENTICATION_SUCCESS = 'AUTHENTICATION_SUCCESS';
export const AUTHENTICATION_FAILURE = 'AUTHENTICATION_FAILURE';
export const LOGOUT_USER = 'LOGOUT_USER';


/**
 * for sitemap
 */

export const FETCHMENU_SUCCESS ='FETCHMENU_SUCCESS';
