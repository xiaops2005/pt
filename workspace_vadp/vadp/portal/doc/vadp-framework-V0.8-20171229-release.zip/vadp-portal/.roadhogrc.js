const publicPath = '/';
export default {
  "entry": "src/index.js",
  "publicPath": publicPath,
  "disableCSSModules":true,
  "define": {
    "publicPath": publicPath,
    "siteName": '望海数据分析平台',
  },
  "extraBabelPlugins": [
    "transform-runtime",
    [
      "module-resolver",
      {
        "root": [
          "./src"
        ],
        "alias": {
          "~": "./src"
        }
      }
    ]
    // ["import", { "libraryName": "antd", "libraryDirectory": "es", "style": true }]
  ],
  "env": {
    "development": {
      "extraBabelPlugins": [
        "dva-hmr"
      ]
    }
  },
  "externals": {
    "echarts": "echarts",
  },
  "proxy": {
    "/sso": {
      "target": "http://127.0.0.1:8081/api",
      "changeOrigin": true,
      "pathRewrite": {"^/sso": ""}
    },
    "/api": {
      "target": "http://127.0.0.1:8081",
      "changeOrigin": true,
    }
  },
  "ignoreMomentLocale": true,
  "theme": "./src/theme.js",
  "hash": false
}
