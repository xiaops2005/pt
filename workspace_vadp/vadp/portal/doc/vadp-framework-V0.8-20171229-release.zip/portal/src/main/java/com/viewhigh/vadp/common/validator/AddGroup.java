package com.viewhigh.vadp.common.validator;

/**
 * 新增数据 Group
 */
public interface AddGroup {
}
