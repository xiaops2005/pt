package com.viewhigh.vadp.common.validator;

/**
 * 更新数据 Group
 *
 */

public interface UpdateGroup {
}
