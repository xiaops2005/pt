package com.viewhigh.vadp.common.utils;

public class Constant {
    /** 超级管理员角色 */
    public static final String SUPER_ADMIN = "admin,402882825f0a53b9015f0a53d3910001";
}
