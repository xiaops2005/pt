package com.viewhigh.vadp.framework.plugin;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.plugin.conf.ConfigPath;
import com.viewhigh.vadp.framework.plugin.conf.ConfigPathScanner;
import com.viewhigh.vadp.framework.plugin.manager.PluginsManager;

/**
 * 监控文件夹的改变
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
@WebListener
@ConfigPath(basedirs = { "/OES/plugins","/OES/lib" })
public class PluginMonitorListener implements ServletContextListener {
	private static final Logger logger = LoggerFactory.getLogger(PluginMonitorListener.class);
	private Thread thread = null;
	private String[] rootPaths = null;

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		String[] dirs = new ConfigPathScanner(PluginMonitorListener.class).process();
		rootPaths = dirs;
		logger.debug("初始化插件模块监听器对应的线程");
		ServletContext context = sce.getServletContext();
		for(int j=0;j<rootPaths.length;j++){
		   String rootRealPath = context.getRealPath(rootPaths[j]);
		   File file = new File(rootRealPath);
		   File[] files = file.listFiles();
		   for (int i = 0; i < files.length; i++) {
			   File pluginFile = files[i];
			   if(pluginFile.getName().endsWith(".jar")){
				System.out.println(pluginFile.getName());
				DynamicThermalLoader dtl = new DynamicThermalLoader(context.getClassLoader(),rootRealPath + "/" + pluginFile.getName());
				PluginsManager.CLASS_LOADER_MAP.put(pluginFile.getName(), dtl);
			   }else{
				   DynamicThermalLoader dtl = new DynamicThermalLoader(rootRealPath + "/" + pluginFile.getName(),context.getClassLoader());
				   PluginsManager.CLASS_LOADER_MAP.put(pluginFile.getName(), dtl);
			   }
		   }
		}
		FileChangedMonitorThread monitor = new FileChangedMonitorThread(context);
		thread = new Thread(monitor);
		thread.start();

	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		logger.debug("销毁插件模块监听器对应的线程");
		thread.stop();
		thread.destroy();
	}
}
