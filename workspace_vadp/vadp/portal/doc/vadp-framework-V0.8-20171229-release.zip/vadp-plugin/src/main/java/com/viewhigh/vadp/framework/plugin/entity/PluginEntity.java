package com.viewhigh.vadp.framework.plugin.entity;

import java.util.HashMap;
import java.util.Map;

/**
 * 插件信息映射对象
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */

public class PluginEntity implements Comparable<PluginEntity>{
	private int order;
	private boolean whetherload;
	private boolean webapp;//应用名
	private ModuleEntity module;
	private Map<String, AppEntity> apps = new HashMap<String, AppEntity>();
	private Map<String, ServerPageEntity> serverPages = new HashMap<String, ServerPageEntity>();
	private Map<String, MenuEntity> menus = new HashMap<String, MenuEntity>();
	private Map<String, ResourceEntity> resources = new HashMap<String, ResourceEntity>();
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public boolean isWhetherload() {
		return whetherload;
	}
	public void setWhetherload(boolean whetherload) {
		this.whetherload = whetherload;
	}
	public boolean isWebapp() {
		return webapp;
	}
	public void setWebapp(boolean webapp) {
		this.webapp = webapp;
	}
	public ModuleEntity getModule() {
		return module;
	}
	public void setModule(ModuleEntity module) {
		this.module = module;
	}
	public Map<String, AppEntity> getApps() {
		return apps;
	}
	public void setApps(Map<String, AppEntity> apps) {
		this.apps = apps;
	}
	public Map<String, ServerPageEntity> getServerPages() {
		return serverPages;
	}
	public void setServerPages(Map<String, ServerPageEntity> serverPages) {
		this.serverPages = serverPages;
	}
	public Map<String, MenuEntity> getMenus() {
		return menus;
	}
	public void setMenus(Map<String, MenuEntity> menus) {
		this.menus = menus;
	}
	public Map<String, ResourceEntity> getResources() {
		return resources;
	}
	public void setResources(Map<String, ResourceEntity> resources) {
		this.resources = resources;
	}
	@Override
	public int compareTo(PluginEntity o) {
		if(order<o.order){
            return -1;
        }else if(order==o.order){
        	return 0;
        }else{
        return 1;
    }
	}

}
