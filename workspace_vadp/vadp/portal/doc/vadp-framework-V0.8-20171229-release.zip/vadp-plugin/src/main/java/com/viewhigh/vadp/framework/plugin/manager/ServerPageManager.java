package com.viewhigh.vadp.framework.plugin.manager;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.plugin.DynamicThermalLoader;
import com.viewhigh.vadp.framework.plugin.entity.ServerPageEntity;

/**
 * server page管理器
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
public class ServerPageManager {
	private static final Logger logger = LoggerFactory.getLogger(ServerPageManager.class);
	private static Map<String, ServerPageEntity> serverPages;
	private ServerPageManager(){
		this.serverPages = new HashMap<String, ServerPageEntity>();
	}
	private static final ServerPageManager serverPageManager = new ServerPageManager();
	public static ServerPageManager getInstance(){
		return serverPageManager;
	}
	public Map<String, ServerPageEntity> getServerPages() {
		return serverPages;
	}
	public void setServerPages(Map<String, ServerPageEntity> serverPages) {
		this.serverPages = serverPages;
	}
	public ServerPageEntity getServerPage(String name){
		return serverPages.get(name);
	}
	public static Object createInstance(String name) {
    	Object page = new Object();
    	try {
    		String classname = serverPages.get(name).getClassName();
    		Class c = Class.forName(classname);
    		page = c.newInstance();
		} catch (Exception e) {
			logger.error("创建serverpage实例失败！");
		} 
    	
    	return page;
    }
}
