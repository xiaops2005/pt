package com.viewhigh.vadp.framework.plugin.entity;
/**
 * 基本配置信息
 * 版权所属：东软望海科技有限公司。
 * 作者：毛志全
 * 版本：V1.0
 * 创建日期：2017年12月18日
 * 修改日期: 2017年12月18日
 */
public class ModuleEntity {
private String name;
private String date;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}

}
