package com.viewhigh.vadp.framework.plugin;

import java.io.File;
import java.net.JarURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.plugin.exception.PluginException;

/**
 * 动态加载器
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
public class DynamicThermalLoader extends URLClassLoader {
	private static final Logger logger = LoggerFactory.getLogger(DynamicThermalLoader.class);

	private List<JarURLConnection> jarsToLoad = new ArrayList<JarURLConnection>();

	private String pluginDir = null;

	public DynamicThermalLoader(ClassLoader parentClassLoader, String pluginDir) {
		super(new URL[] {}, parentClassLoader);
		this.pluginDir = pluginDir;
		constructJarFiles(this.pluginDir);
	}
	public DynamicThermalLoader(String pluginDir,ClassLoader parentClassLoader) {
		super(new URL[] {}, parentClassLoader);
		this.pluginDir = pluginDir;
		constructPluginFiles(this.pluginDir+"/lib/");
	}
	/**
	* 将指定的jar文件url添加到类加载器的classpath中去
	* @param ：jar文件的url
	 * @throws MalformedURLException 
	*/
	public void addURLFile(URL file,File filepath) throws MalformedURLException {
		try {
			// 打开并缓存文件url连接
			URLConnection uc = file.openConnection();
			if (uc instanceof JarURLConnection) {
				uc.setUseCaches(true);
				((JarURLConnection) uc).getManifest();
				jarsToLoad.add((JarURLConnection) uc);
			}
		} catch (Exception e) {
			logger.error("不能够缓存加载jar文件: " + file.toExternalForm(), e);
		}
		//addURL(new URL("file:/E:\\workspace0.8\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\vadp-web\\WEB-INF\\plugins\\plugin3\\lib\\SayHello.jar"));
		addURL(filepath.toURI().toURL());

		System.out.println(file.getPath());
	}

	/**
	* 卸载jar包
	*/
	public void unloadJarFiles() {
		for (JarURLConnection url : jarsToLoad) {
			try {
				logger.info("卸载jar文件：" + url.getJarFile().getName());
				url.getJarFile().close();
				url = null;
			} catch (Exception e) {
				logger.error("失败卸载jar文件", e);
			}
		}
	}

	/**
	 * 取得组件中的所有jar文件
	 * @param pluginDir
	 * @return
	 */
	private void constructJarFiles(String pluginDir) {
		try {
			File file = new File(pluginDir);
			/*File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++) {
				File jarFile = files[i];
				logger.error("加载jar文件: " + file.getName());*/
				//URL url = new URL("jar:file:/"+jarFile.getAbsolutePath()+"!/");
			URL url = new URL("jar:file:/"+pluginDir+"!/");
				//addURLFile(jarFile.toURI().toURL());
				//addURLFile(url,jarFile);
				addURLFile(url,file);
			//}
		} catch (Exception e) {
			logger.info("加载jar文件错误：");
			throw new PluginException(e);
		}
	}
	/**
	 * 取得组件中的所有jar文件
	 * @param pluginDir
	 * @return
	 */
	private void constructPluginFiles(String pluginDir) {
		try {
			File file = new File(pluginDir);
			File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++) {
				File jarFile = files[i];
				logger.error("加载jar文件: " + file.getName());
				URL url = new URL("jar:file:/"+jarFile.getAbsolutePath()+"!/");
			//URL url = new URL("jar:file:/"+pluginDir+"!/");
				//addURLFile(jarFile.toURI().toURL());
				addURLFile(url,jarFile);
				//addURLFile(url,file);
			}
		} catch (Exception e) {
			logger.info("加载jar文件错误：");
			throw new PluginException(e);
		}
	}
}
