package com.viewhigh.vadp.framework.plugin.manager;

import java.util.HashMap;
import java.util.Map;

import com.viewhigh.vadp.framework.plugin.entity.MenuEntity;
import com.viewhigh.vadp.framework.plugin.entity.ServerPageEntity;

/**
 * 菜单管理器
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
public class MenuManager {
	private Map<String, MenuEntity> menus ;
	private MenuManager(){
		this.menus = new HashMap<String, MenuEntity>();
	}
	private static final MenuManager menuManager = new MenuManager();
	public static MenuManager getInstance(){
		return menuManager;
	}
	public Map<String, MenuEntity> getMenus() {
		return menus;
	}
	public void setMenus(Map<String, MenuEntity> menus) {
		this.menus = menus;
	}
	public MenuEntity getMenu(String name){
		return menus.get(name);
	}
}
