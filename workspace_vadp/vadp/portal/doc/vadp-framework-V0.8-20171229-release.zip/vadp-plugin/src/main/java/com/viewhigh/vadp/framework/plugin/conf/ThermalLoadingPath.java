package com.viewhigh.vadp.framework.plugin.conf;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 热加载路径扫描
 * 版权所属：东软望海科技有限公司。
 * 作者：毛志全
 * 版本：V1.0
 * 创建日期：2017年12月26日
 * 修改日期: 2017年12月26日
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
public @interface ThermalLoadingPath {
	/**
	 * 热加载路径
	 * @return
	 */
	String[] basedirs() default {};
}
