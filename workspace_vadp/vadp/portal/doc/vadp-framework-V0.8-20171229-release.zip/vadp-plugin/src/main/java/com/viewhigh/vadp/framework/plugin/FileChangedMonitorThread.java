package com.viewhigh.vadp.framework.plugin;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.minlog.Log;
import com.viewhigh.vadp.framework.plugin.conf.PluginConfParse;
import com.viewhigh.vadp.framework.plugin.conf.ConfigPath;
import com.viewhigh.vadp.framework.plugin.conf.ConfigPathScanner;
import com.viewhigh.vadp.framework.plugin.exception.PluginException;
import com.viewhigh.vadp.framework.plugin.manager.PluginsManager;

/**
 * 实现组件监控的独立线程
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
@ConfigPath(basedirs = { "/OES/plugins" })
public class FileChangedMonitorThread implements Runnable {
	private static final Logger logger = LoggerFactory.getLogger(PluginMonitorListener.class);
	private String[] rootPaths = null;
	private String rootAbsolutePath = null;
	private WatchService watchService;
	private ServletContext context;

	public FileChangedMonitorThread(ServletContext context) {
		this.context = context;
	}

	/**
	 * 设置监控目录
	 * @param dirPath
	 */
	private void init() {

		try {
			String[] dirs = new ConfigPathScanner(FileChangedMonitorThread.class).process();
			rootPaths = dirs;
			for(int i=0;i<rootPaths.length;i++){
			Path path = Paths.get(context.getRealPath(rootPaths[i]));
			this.rootAbsolutePath = path.toAbsolutePath().toString();
			logger.info("监控文件路径..." + path.toAbsolutePath());
			//创建watchService
			watchService = FileSystems.getDefault().newWatchService();
			//注册需要监控的事件,ENTRY_CREATE 文件创建,ENTRY_MODIFY 文件修改,ENTRY_MODIFY 文件删除
			path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE);
			}
			} catch (Exception e) {
			throw new PluginException("初始化文件夹监控错误", e);
		}
	}

	public void start() {
		logger.info("开始监控...");
		while (true) {
			try {
				WatchKey watchKey = watchService.poll(15, TimeUnit.SECONDS); //10秒钟
				if (watchKey != null) {
					List<WatchEvent<?>> events = watchKey.pollEvents();//获取所有得事件
					for (WatchEvent event : events) {
						WatchEvent.Kind<?> kind = event.kind();
						if (kind == StandardWatchEventKinds.OVERFLOW) {
							continue;
						}
						WatchEvent<Path> ev = event;
						Path path = ev.context();
						String pluginName = path.getName(0).toString();
						//plugin目录下xml文件绝对路径
						String pluginconf = this.rootAbsolutePath + "\\" + pluginName + "\\" + pluginName+".plugin.xml";
						//先卸载对应的插件加载的jar
						if (PluginsManager.CLASS_LOADER_MAP.containsKey(pluginName)) {
							PluginsManager.CLASS_LOADER_MAP.get(pluginName).unloadJarFiles();
						}
						if (kind == StandardWatchEventKinds.ENTRY_MODIFY||kind == StandardWatchEventKinds.ENTRY_CREATE) {
							DynamicThermalLoader dtl = new DynamicThermalLoader(context.getClassLoader(),this.rootAbsolutePath + "\\" + pluginName +"\\" +"lib");
							
							PluginsManager.CLASS_LOADER_MAP.put(pluginName, dtl);
							logger.info("修改插件..." + this.rootAbsolutePath + "\\" + pluginName);
							//调用服务端页面管理对象		
							PluginsManager.getInstance().addPath(pluginconf);
							PluginsManager.getInstance().load();
						} 
					    
					}
					if (!watchKey.reset()) {
						//已经关闭了进程
						logger.info("退出监控...");
						break;
					}
				}
			} catch (Exception e) {
				Log.error("启动文件监控错误", e);
				throw new PluginException("启动文件监控错误", e);
			}

		}
	}

	@Override
	public void run() {
		init();
		start();

	}
	
	//	/**
	//	 * 监控文件系统改变
	//	 */
	//	public void monitor() {
	//		try {
	//			final Path path = Paths.get(".");
	//			final WatchService watchService = path.getFileSystem().newWatchService();
	//			path.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
	//			final WatchKey watchKey = watchService.poll(1, TimeUnit.MINUTES);
	//			if(watchKey != null) {
	//			    watchKey.pollEvents().stream().forEach(event ->
	//			    System.out.println(event.context()));
	//			}
	//			
	////			fsManager = VFS.getManager();
	////			FileObject listendir = null;
	////			listendir = fsManager.resolveFile(new File(rootPath).getAbsolutePath());
	////			DefaultFileMonitor fm = new DefaultFileMonitor(new FileListener() {
	////				@Override
	////				public void fileChanged(FileChangeEvent event) throws Exception {
	////					FileObject fileObject = event.getFile();
	////					String path = fileObject.getName().getPath();
	////					//监控文件夹的改变，是否rootPath发生成了改变
	////					if (FileType.FOLDER.equals(fileObject.getType()) && path.contains(rootPath)) {
	////						logger.info("监控到插件发生改变：" + path);
	////					}
	////				}
	////
	////				@Override
	////				public void fileCreated(FileChangeEvent arg0) throws Exception {
	////					logger.info("监控到插件发生改变：");
	////				}
	////
	////				@Override
	////				public void fileDeleted(FileChangeEvent arg0) throws Exception {
	////					logger.info("监控到插件发生改变：" );
	////				}
	////			});
	////			//是否递归
	////			fm.setRecursive(false);
	////			fm.addFile(listendir);
	////			fm.start();
	//
	//		} catch (Exception e) {
	//			throw new PluginException("启动文件监控错误", e);
	//		}

	//	}
}
