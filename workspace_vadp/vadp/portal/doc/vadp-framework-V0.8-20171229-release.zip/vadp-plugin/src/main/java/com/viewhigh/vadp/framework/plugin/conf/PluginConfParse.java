package com.viewhigh.vadp.framework.plugin.conf;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.plugin.PluginMonitorListener;
import com.viewhigh.vadp.framework.plugin.entity.AppEntity;
import com.viewhigh.vadp.framework.plugin.entity.MenuEntity;
import com.viewhigh.vadp.framework.plugin.entity.ModuleEntity;
import com.viewhigh.vadp.framework.plugin.entity.PluginEntity;
import com.viewhigh.vadp.framework.plugin.entity.ResourceEntity;
import com.viewhigh.vadp.framework.plugin.entity.ServerPageEntity;
import com.viewhigh.vadp.framework.plugin.exception.PluginException;

/**
 * 插件配置文件解析器
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年4月25日
 * 修改日期: 2017年4月25日
 */
public class PluginConfParse {
	
	private static final Logger logger = LoggerFactory.getLogger(PluginConfParse.class);
	
	/**
     * 解析plugin目录下xml文件
	 */
	public PluginEntity parserXml(String filePath) {
		Map<String, AppEntity> apps = new HashMap<String, AppEntity>();
	    Map<String, ServerPageEntity> serverPages = new HashMap<String, ServerPageEntity>();
		Map<String, MenuEntity> menus = new HashMap<String, MenuEntity>();
		Map<String, ResourceEntity> resources = new HashMap<String, ResourceEntity>();
		PluginEntity pluginEntity = new PluginEntity();
		SAXReader saxReader=new SAXReader();
		try {
			Document document = saxReader.read(filePath);
			//获取根元素
	        Element rootElement=document.getRootElement();
	      //获取whetherload标签
	        Element whetherloadElm = rootElement.element("whetherload");
	        String whetherloadText = whetherloadElm.getText();
	        pluginEntity.setWhetherload(Boolean.parseBoolean(whetherloadText));
	        //获取webapp标签
	        Element webappElm = rootElement.element("webapp");
	        String webappText = webappElm.getText();
	        pluginEntity.setWebapp(Boolean.parseBoolean(webappText));
	        //获取baseInfo标签
	        Element baseInfoElm = rootElement.element("baseInfo");
	        Element moduleElm = baseInfoElm.element("module");
	        String name = moduleElm.attributeValue("name");
	        String date = moduleElm.attributeValue("date");
	        ModuleEntity moduleEntity = new ModuleEntity();
	        moduleEntity.setName(name);
	        moduleEntity.setDate(date);
	        //获取apps标签
	        Element appsElm = rootElement.element("apps");
		    Iterator appit=appsElm.elementIterator("app");
		    while(appit.hasNext())
		         {
		        	AppEntity appEntity = new AppEntity();
		            Element appElement= (Element) appit.next();
		            appEntity.setId(appElement.attributeValue("id")); 
		            appEntity.setName(appElement.attributeValue("name"));
		            apps.put(appEntity.getId(), appEntity);
		         }
	        //获取serverpage标签
	        Element serverPagesElm = rootElement.element("serverpages");
		    Iterator serverpageit=serverPagesElm.elementIterator("serverpage");
		    while(serverpageit.hasNext())
		         {
		        	ServerPageEntity serverPageEntity = new ServerPageEntity();
		            Element serverpageElement= (Element) serverpageit.next();
		            serverPageEntity.setName(serverpageElement.attributeValue("name"));
		            serverPageEntity.setClassName(serverpageElement.attributeValue("className"));  
		            serverPageEntity.setUrl(serverpageElement.attributeValue("url"));
		            serverPageEntity.setType(serverpageElement.attributeValue("type"));
		            serverPageEntity.setDescription(serverpageElement.attributeValue("description"));
		            serverPages.put(serverPageEntity.getName(), serverPageEntity);
		         }
	        //获取menu标签
	        Element menusElm = rootElement.element("menus");
	        Iterator menuit=menusElm.elementIterator("menu");
	        while(menuit.hasNext())
	         {
	        	MenuEntity menuEntity = new MenuEntity();
	            Element menuElement= (Element) menuit.next();
	            menuEntity.setId(menuElement.attributeValue("id"));  
	            menuEntity.setTitle(menuElement.attributeValue("title"));
	            menuEntity.setUrl(menuElement.attributeValue("url"));
	            menuEntity.setParent(menuElement.attributeValue("parent"));
	            menuEntity.setIcon(menuElement.attributeValue("icon"));
	            menuEntity.setApp(menuElement.attributeValue("app"));
	            menus.put(menuEntity.getId(), menuEntity);
	            
	         }
	         
		     //获取resource标签
		     Element resourcesElm = rootElement.element("resources");
			 Iterator resourcesiter=resourcesElm.elementIterator("resource");
			 while(resourcesiter.hasNext())
			      {
			        ResourceEntity resourceEntity = new ResourceEntity();
			        Element resourceElement= (Element) resourcesiter.next();
			        resourceEntity.setPath(resourceElement.getText());
			        resources.put(resourceEntity.getPath(), resourceEntity);
			       }
			 pluginEntity.setModule(moduleEntity);
			 pluginEntity.setApps(apps);
			 pluginEntity.setMenus(menus);
			 pluginEntity.setServerPages(serverPages);
			 pluginEntity.setResources(resources);
			 } catch (DocumentException e) {
				 logger.error("xml文件解析失败！");
                      throw new PluginException("xml文件解析失败！",e,true,true);
			   }//引入XML文件路径
			return pluginEntity;
	}
}
