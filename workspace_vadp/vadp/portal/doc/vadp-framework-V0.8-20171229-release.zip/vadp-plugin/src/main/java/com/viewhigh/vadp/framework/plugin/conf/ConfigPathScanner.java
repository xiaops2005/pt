package com.viewhigh.vadp.framework.plugin.conf;


public class ConfigPathScanner {
   private Class<?> scannerClass;
   public ConfigPathScanner(Class<?> scannerClass){
	   this.scannerClass = scannerClass;
   }
   public String[] process(){
	   String[] path = null;
	   if(scannerClass.isAnnotationPresent(ConfigPath.class)){
		   ConfigPath thermalLoadingPath = (ConfigPath)scannerClass.getAnnotation(ConfigPath.class);
	       path = thermalLoadingPath.basedirs();
	   }
	   return path;
   }
}
