package com.viewhigh.vadp.framework.session.init;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionBasicInfo;
import com.viewhigh.vadp.framework.session.SessionStore;
import com.viewhigh.vadp.framework.session.impl.HttpSessionImpl;
import com.viewhigh.vadp.framework.session.impl.RedisSessionStore;
import com.viewhigh.vadp.framework.session.util.SessionUtil;
import com.viewhigh.vadp.framework.session.util.SimpleStringUtil;
import com.viewhigh.vadp.framework.session.util.StringUtil;

/**
 * 
 * 
 * 提供对会话框架初始化的工作和SessionFilter的功能类似，但是它可以独立进行初始化或使用
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年7月4日
 * 修改日期: 2017年7月4日
 */
public class SessionHelper {
	//如果是过滤器链表调用该助手类那么在第一次请求的时候，需要将新产生的sessionID保存到request中，因为这个时候cookies还没有返回前台，
	//请求中获取不到，会让后续的过滤器取不到对应的session
	private static String FILETE_CHAIN_SESSION_VALUE_KEY="com.viewhigh.vadp.framework.session.init.SessionHelper_FILETE_CHAIN_SESSION_VALUE_KEY";
	public static void init(boolean useWebSession) {
		SessionUtil.getSessionManager().setUseWebSession(useWebSession);
		//当时用自定义的redis存储的时候对session管理器进行初始化
		if (!SessionUtil.getSessionManager().useWebSession()) {
			SessionStore ss = new RedisSessionStore();
			ss.setSessionManager(SessionUtil.getSessionManager());
			SessionUtil.getSessionManager().setSessionStore(ss);
		}
	}

	public static HttpSession getSession(ServletRequest req, ServletResponse res) {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		HttpSession session;
		String sessionID = StringUtil.getCookieValue(
				(HttpServletRequest) request, SessionUtil.getSessionManager()
						.getCookieName());
		//如果是过滤器链表调用该助手类那么在第一次请求的时候，需要将新产生的sessionID保存到request中，因为这个时候cookies还没有返回前台，
		//请求中获取不到，会让后续的过滤器取不到对应的session,所以需要从request中再取一下，这个功能只影响过滤器链表的场景。
		sessionID=(String) (sessionID==null?request.getAttribute(FILETE_CHAIN_SESSION_VALUE_KEY):sessionID);
		if (SessionUtil.getSessionManager().useWebSession()) {
			session = request.getSession();
		} else {
			//当会话id为空的时候，就创建session对象，然后将sessionId放到cookie中
			if (sessionID == null) {
				SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
				sessionBasicInfo.setReferIP(SimpleStringUtil
						.getClientIp(request));
				sessionBasicInfo.setRequestURI(request.getRequestURI());
				session = SessionUtil.createSession(
						request.getServletContext(), sessionBasicInfo);
				sessionID = session.getId();
				SessionUtil.getSessionManager().setCookieName(sessionID);
				SessionUtil.writeCookies(request, response, sessionID);
				request.setAttribute(FILETE_CHAIN_SESSION_VALUE_KEY, sessionID);
			} else {
				Session sessionInfo = SessionUtil.getSession(sessionID);
				// session不存在，创建新的session
				if (sessionInfo == null) {
					SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
					sessionBasicInfo.setReferIP(SimpleStringUtil
							.getClientIp(request));
					sessionBasicInfo.setRequestURI(request.getRequestURI());
					session = (HttpSessionImpl) SessionUtil.createSession(
							request.getServletContext(), sessionBasicInfo);
					sessionID = session.getId();
					SessionUtil.getSessionManager().setCookieName(sessionID);
					SessionUtil.writeCookies(request, response, sessionID);
				} else {
					session = new HttpSessionImpl(sessionInfo,
							request.getServletContext());
				}

			}
		}
		return session;
	}
}
