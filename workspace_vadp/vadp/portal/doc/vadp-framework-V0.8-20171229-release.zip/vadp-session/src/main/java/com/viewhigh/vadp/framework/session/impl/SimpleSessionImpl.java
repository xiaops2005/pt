package com.viewhigh.vadp.framework.session.impl;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionStore;
import com.viewhigh.vadp.framework.session.util.SessionUtil;

/**
 * 
 * 默认的session存储上下文
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SimpleSessionImpl implements Session {

	private String id;
	private long creationTime;
	private long lastAccessedTime;
	private long maxInactiveInterval;
	private String referip;
	private boolean validate;
	private boolean dovalidate;
	private Boolean assertValidate = null;
	private transient SessionStore sessionStore;
	private transient Map<String, Object> attributes;
	private static final Object NULL = new Object();
	private String host;
	private String requesturi;
	private String lastAccessedUrl;
	private boolean httpOnly;
	private boolean secure;
	private String lastAccessedHostIP;

	public SimpleSessionImpl() {
		attributes = new HashMap<String, Object>();
	}

	private void assertSession(HttpSession session) {

		if (assertValidate != null) {

		} else {
			synchronized (this) {
				if (assertValidate == null) {
					assertValidate = new Boolean(this.isValidate());
				}
			}

		}
		if (!assertValidate.booleanValue()) {
			this.invalidate(session);
			// throw new SessionInvalidateException("Session " +this.getId() +
			// "已经失效!");
			throw new IllegalStateException("Session " + this.getId() + "已经失效!");
		}

	}

	public Object getCacheAttribute(String attribute) {
		Object value = this.attributes.get(attribute);
		if (value == NULL)
			return null;
		else
			return value;
	}

	public Object getAttribute(HttpSession session, String attribute) {
		assertSession(session);
		if (!SessionUtil.getSessionManager().cacheAttribute()) {
			return sessionStore.getAttribute( id, attribute);
		} else {
			Object value = this.attributes.get(attribute);
			if (value == null) {
				value = sessionStore.getAttribute( id, attribute);
				if (value != null) {
					this.attributes.put(attribute, value);
				} else {
					this.attributes.put(attribute, NULL);
				}
				return value;
			} else {
				if (value == NULL)
					return null;
				else
					return value;
			}
		}
	}

	public Enumeration getAttributeNames(HttpSession session) {
		assertSession(session);
		return sessionStore.getAttributeNames( id);
	}

	public long getCreationTime() {
		// assertSession() ;
		return creationTime;
	}

	public String getId() {
		return id;
	}

	public void touch(HttpSession session, String lastAccessedUrl) {
		assertSession(session);
		lastAccessedTime = System.currentTimeMillis();
		sessionStore.updateLastAccessedTime(id, lastAccessedTime,
				lastAccessedUrl, this.getMaxInactiveInterval());
		// assertSession() ;

	}

	public long getLastAccessedTime() {
		return lastAccessedTime = sessionStore.getLastAccessedTime(id);
	}

	public long getMaxInactiveInterval() {

		return maxInactiveInterval;
	}

	public Object getValue(HttpSession session, String attribute) {
		return getAttribute(session, attribute);
	}

	public String[] getValueNames(HttpSession session) {
		assertSession(session);
		if (!this.isValidate()) {
			return null;
		}
		return sessionStore.getValueNames( id);
	}

	public void invalidate(HttpSession session) {

		if (!dovalidate) {
			this.dovalidate = true;
			if (validate) {
				sessionStore.invalidate(session,  id);
				this.validate = false;
				this.attributes.clear();
			}
		}

	}

	public boolean isNew() {
		// return this.creationTime == this.lastAccessedTime;
		return isNew;
	}

	protected boolean isNew = false;

	public void putNewStatus() {
		this.isNew = true;
	}

	public void putValue(HttpSession session, String attribute, Object value) {
		setAttribute(session, attribute, value);

	}

	public void removeAttribute(HttpSession session, String attribute) {
		assertSession(session);
		if (!this.isValidate()) {
			return;
		}
		sessionStore.removeAttribute(session,  id, attribute);
		// this.attributes.remove(attribute);
		// 将属性设置为空避免重复从mongodb获取数据
		this.attributes.put(attribute, NULL);

	}

	public void removeValue(HttpSession session, String attribute) {
		removeAttribute(session, attribute);

	}

	public void setAttribute(HttpSession session, String attribute,
			Object value) {
		assertSession(session);
		if (SessionUtil.getSessionManager().cacheAttribute()) {
			this.attributes.put(attribute, value);
		}
		sessionStore.addAttribute(session,  id, attribute, value);
	}

	public void setMaxInactiveInterval(long maxInactiveInterval) {
		this.maxInactiveInterval = maxInactiveInterval;

	}

	public SessionStore _getSessionStore() {
		return sessionStore;
	}

	public void _setSessionStore(SessionStore sessionStore) {
		this.sessionStore = sessionStore;
	}

	public void setCreationTime(long creationTime) {
		this.creationTime = creationTime;
	}

	public void setLastAccessedTime(long lastAccessedTime) {
		this.lastAccessedTime = lastAccessedTime;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReferip() {
		return referip;
	}

	public void setReferip(String referip) {
		this.referip = referip;
	}

	public boolean isValidate() {
		if (!validate)
			return false;
		return this.maxInactiveInterval <= 0
				|| (this.lastAccessedTime + this.maxInactiveInterval) > System
						.currentTimeMillis();
		// return validate;
	}

	public void setValidate(boolean validate) {
		this.validate = validate;
	}

	public Map<String, Object> getAttributes() {
		// assertSession() ;
		return attributes;
	}

	public void setAttributes(Map<String, Object> attributes) {
		// assertSession() ;
		this.attributes = attributes;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getRequesturi() {
		return requesturi;
	}

	public void setRequesturi(String requesturi) {
		this.requesturi = requesturi;
	}

	public String getLastAccessedUrl() {
		return lastAccessedUrl;
	}

	public void setLastAccessedUrl(String lastAccessedUrl) {
		this.lastAccessedUrl = lastAccessedUrl;
	}

	public boolean isHttpOnly() {
		return httpOnly;
	}

	public void setHttpOnly(boolean httpOnly) {
		this.httpOnly = httpOnly;
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}

	public String getLastAccessedHostIP() {
		return lastAccessedHostIP;
	}

	public void setLastAccessedHostIP(String lastAccessedHostIP) {
		this.lastAccessedHostIP = lastAccessedHostIP;
	}

}
