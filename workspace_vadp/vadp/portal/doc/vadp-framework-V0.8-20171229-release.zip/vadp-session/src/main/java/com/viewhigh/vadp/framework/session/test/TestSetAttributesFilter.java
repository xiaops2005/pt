package com.viewhigh.vadp.framework.session.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.init.SessionHelper;
/**
 * 
 * 设置属性测试类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年7月4日
 * 修改日期: 2017年7月4日
 */
public class TestSetAttributesFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest) req;

		HttpSession hs=SessionHelper.getSession(request, response);
		System.out.print("sessid set---------------------------->"+hs.getId());
		Map<String,String> a=new HashMap<String,String>();
		a.put("1", "1");
		a.put("2", "2");
		hs.setAttribute("a", a);
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
