package com.viewhigh.vadp.framework.session;

/**
 * session状态监听接口
 * 描述信息
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public interface SessionListener {
	public void onCreateSession(SessionEvent event);

	public void onDestroySession(SessionEvent event);

	public void onAddAttribute(SessionEvent event);

	public void onRemoveAttribute(SessionEvent event);
}
