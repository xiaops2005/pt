package com.viewhigh.vadp.framework.session.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.session.SessionEvent;
import com.viewhigh.vadp.framework.session.SessionListener;

/**
 * 
 * 默认的session监听器
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class NullSessionListener implements SessionListener {
	private static Logger log = LoggerFactory
			.getLogger(NullSessionListener.class);

	public void onCreateSession(SessionEvent event) {
		log.debug("createSession session id:" + event.getSource().getId());
	}

	public void onDestroySession(SessionEvent event) {
		log.debug("destroySession session id:" + event.getSource().getId());

	}

	public void onAddAttribute(SessionEvent event) {
		log.debug("addAttribute session id:" + event.getSource().getId()
				+ ",attirbute name is " + event.getAttributeName());

	}

	public void onRemoveAttribute(SessionEvent event) {
		log.debug("removeAttribute session id:" + event.getSource().getId()
				+ ",attirbute name is " + event.getAttributeName());
	}

}
