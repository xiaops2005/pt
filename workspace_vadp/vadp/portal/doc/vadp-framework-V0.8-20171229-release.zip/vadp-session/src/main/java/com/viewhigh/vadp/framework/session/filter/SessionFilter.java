package com.viewhigh.vadp.framework.session.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.viewhigh.vadp.framework.session.SessionStore;
import com.viewhigh.vadp.framework.session.impl.RedisSessionStore;
import com.viewhigh.vadp.framework.session.util.SessionUtil;

/**
 * 对系统所有请求的拦截，拦截后对请求进行封装
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionFilter implements Filter {

	private ServletContext servletContext;
	private String useWebSession;
	private FilterConfig fc;

	public void destroy() {
		servletContext = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		if (SessionUtil.getSessionManager().useWebSession()) {
			filterChain.doFilter(request, response);
		} else {
			SessionHttpServletRequestWrapper shsrw = new SessionHttpServletRequestWrapper(
					(HttpServletRequest) request,
					(HttpServletResponse) response, servletContext);
			shsrw.touch();
			filterChain.doFilter(shsrw, response);
		}
	}

	public void init(FilterConfig config) throws ServletException {
		servletContext = config.getServletContext();
		this.fc = config;
		this.setUseWebSession(useWebSession);
		SessionUtil.getSessionManager().setUseWebSession(
				Boolean.parseBoolean(getUseWebSession()));
		//当时用自定义的redis存储的时候对session管理器进行初始化
		if (!SessionUtil.getSessionManager().useWebSession()) {
			SessionStore ss = new RedisSessionStore();
			ss.setSessionManager(SessionUtil.getSessionManager());
			SessionUtil.getSessionManager().setSessionStore(ss);
		}
	}

	public String getUseWebSession() {
		if (useWebSession == null) {
			useWebSession = fc.getInitParameter("useWebSession");
		}
		return useWebSession;
	}

	public void setUseWebSession(String useWebSession) {
		this.useWebSession = useWebSession;
	}

}
