package com.viewhigh.vadp.framework.session;

import javax.servlet.http.HttpSession;

/**
 * 
 * session事件接口
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public interface SessionEvent {
	public final int EventType_create = 0;
	public final int EventType_destroy = 1;
	public final int EventType_addAttibute = 2;
	public final int EventType_removeAttibute = 3;

	public HttpSession getSource();

	public int getEventType();

	public String getAttributeName();

	public Object getAttributeValue();
}
