package com.viewhigh.vadp.framework.session.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.viewhigh.vadp.framework.session.SessionEvent;
import com.viewhigh.vadp.framework.session.SessionListener;
import com.viewhigh.vadp.framework.session.SessionStore;

/**
 * 实现对会话的管理，可以灵活的切换会话是采用基本的HttpSession方式，还是redis缓存方式
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
@Service("distributedSessionManager")
public class SessionManager {

	private Logger log = LoggerFactory.getLogger(SessionManager.class);

	/**
	 * 是否将attribute缓存在本地，默认开启
	 */
	private boolean cacheAttribute = true;

	private long sessionTimeout = 3600000;
	/**
	 * 是否使用本地session，默认开启
	 */
	private boolean useWebSession = true;
	private String cookieName;

	private boolean httpOnly;
	private boolean secure;
	private String domain;

	/**
	 * 应用编码，如果没有指定appCode值默认为应用上下文,appCode的作用：当所有的应用上下文为/时，用来区分后台统计的会话信息
	 */
	//	private String appCode;

	private int cookieLiveTime = -1;
	private SessionStore sessionStore;
//	private SessionMonitor sessionMonitor;
	private List<SessionListener> sessionListeners;

	/**
	 * session超时检测时间间隔，默认为-1，不检测 如果需要检测，那么只要令牌持续时间超过sessionScanInterval
	 * 对应的时间将会被清除
	 */
	private long sessionScanInterval = 60 * 60000;

	public long getSessionTimeout() {
		return sessionTimeout;
	}

	public void setSessionTimeout(long sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	public String getCookieName() {
		return cookieName;
	}

	public void setCookieName(String cookieName) {
		this.cookieName = cookieName;
	}

	public boolean isHttpOnly() {
		return httpOnly;
	}

	public void setHttpOnly(boolean httpOnly) {
		this.httpOnly = httpOnly;
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public int getCookieLiveTime() {
		return cookieLiveTime;
	}

	public void setCookieLiveTime(int cookieLiveTime) {
		this.cookieLiveTime = cookieLiveTime;
	}

	public SessionStore getSessionStore() {
		return sessionStore;
	}

	public void setSessionStore(SessionStore sessionStore) {
		this.sessionStore = new DelegateSessionStore(sessionStore);
	}

//	public SessionMonitor getSessionMonitor() {
//		return sessionMonitor;
//	}
//
//	public void setSessionMonitor(SessionMonitor sessionMonitor) {
//		this.sessionMonitor = sessionMonitor;
//	}

	public List<SessionListener> getSessionListeners() {
		return sessionListeners;
	}

	public void setSessionListeners(List<SessionListener> sessionListeners) {
		this.sessionListeners = sessionListeners;
	}

	public long getSessionScanInterval() {
		return sessionScanInterval;
	}

	public void setSessionScanInterval(long sessionScanInterval) {
		this.sessionScanInterval = sessionScanInterval;
	}

	public boolean isCacheAttribute() {
		return cacheAttribute;
	}

	public boolean cacheAttribute() {
		return cacheAttribute;
	}

	public void setCacheAttribute(boolean cacheAttribute) {
		this.cacheAttribute = cacheAttribute;
	}

	public void setUseWebSession(boolean useWebSession) {
		this.useWebSession = useWebSession;
	}

	public boolean useWebSession() {
		return useWebSession;
	}

	public void destroy() {
		if (sessionStore != null)
			this.sessionStore.destroy();
//		if (this.sessionMonitor != null) {
//			this.sessionMonitor.killdown();
//		}

	}

	public boolean haveSessionListener() {
		return this.sessionListeners != null
				&& this.sessionListeners.size() > 0;
	}

	public void dispatchEvent(SessionEvent sessionEvent) {
		for (int i = 0; sessionListeners != null
				&& i < this.sessionListeners.size(); i++) {

			switch (sessionEvent.getEventType()) {
			case SessionEvent.EventType_create:
				try {
					sessionListeners.get(i).onCreateSession(sessionEvent);
				} catch (Exception e) {
					log.error("", e);
				}
				break;
			case SessionEvent.EventType_destroy:
				try {
					sessionListeners.get(i).onDestroySession(sessionEvent);
				} catch (Exception e) {
					log.error("", e);
				}
				break;
			case SessionEvent.EventType_addAttibute:
				try {
					sessionListeners.get(i).onAddAttribute(sessionEvent);
				} catch (Exception e) {
					log.error("", e);
				}
				break;
			case SessionEvent.EventType_removeAttibute:
				try {
					sessionListeners.get(i).onRemoveAttribute(sessionEvent);
				} catch (Exception e) {
					log.error("", e);
				}
				break;
			default:
				throw new RuntimeException("未知的事件类型："
						+ sessionEvent.getEventType());
			}

		}

	}
//
//	class SessionMonitor extends Thread {
//		public void killdown() {
//
//		}
//	}
}
