package com.viewhigh.vadp.framework.session;

import java.util.Enumeration;

import javax.servlet.http.HttpSession;

/**
 * 
 * 自定义session的接口
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public interface Session {

	public Object getAttribute(HttpSession session, String attribute);

	public Object getCacheAttribute(String attribute);

	public Enumeration getAttributeNames(HttpSession session);

	public long getCreationTime();

	public String getId();

	/**
	 * 更新最后访问时间
	 */
	public void touch(HttpSession session, String lastAccessedUrl);

	public long getLastAccessedTime();

	public void setLastAccessedTime(long lastAccessedTime);

	public long getMaxInactiveInterval();

	public Object getValue(HttpSession session, String attribute);

	public String[] getValueNames(HttpSession session);

	public void invalidate(HttpSession session);

	public boolean isNew();

	public void putValue(HttpSession session, String attribute, Object value);

	public void removeAttribute(HttpSession session, String attribute);

	public void removeValue(HttpSession session, String attribute);

	public void setAttribute(HttpSession session, String attribute, Object value);

	public void setMaxInactiveInterval(long maxInactiveInterval);

	public String getReferip();

	public boolean isValidate();

	public void _setSessionStore(SessionStore sessionStore);

	public void putNewStatus();

	public String getRequesturi();

	public void setRequesturi(String requesturi);
}
