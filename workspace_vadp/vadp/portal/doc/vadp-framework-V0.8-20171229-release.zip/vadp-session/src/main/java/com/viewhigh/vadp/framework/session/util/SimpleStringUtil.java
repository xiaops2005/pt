package com.viewhigh.vadp.framework.session.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

/**
 * 
 * 描述信息
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SimpleStringUtil {
	private static String ip;
	static {
		try {
			InetAddress addr = InetAddress.getLocalHost();
			String ip_ = addr.getHostAddress();// 获得本机IP
			String address = addr.getHostName();// 获得本机名称
			ip = ip_ + "-" + address;
		} catch (Exception e) {
			e.printStackTrace();
			ip = "";
		}
	}

	public static String getHostIP() {
		return ip;
	}

	/**
	 * 将字符串转化为位置
	 * @param values
	 * @return
	 */
	public static Enumeration arryToenum(final Object[] values) {
		return new Enumeration() {
			int length = values != null ? values.length : 0;
			int count = 0;

			public boolean hasMoreElements() {

				return count < length;
			}

			public Object nextElement() {
				Object element = values[count];
				count++;
				return element;
			}
		};
	}

	/**
	 * 取得客户端ip信息
	 * @param request
	 * @return
	 */
	public static String getClientIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip)))
			ip = request.getHeader("Proxy-Client-IP");
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip)))
			ip = request.getHeader("WL-Proxy-Client-IP");
		if ((ip == null) || (ip.length() == 0)
				|| ("unknown".equalsIgnoreCase(ip))) {
			ip = request.getRemoteAddr();
			if ((ip.equals("127.0.0.1")) || (ip.equals("0:0:0:0:0:0:0:1"))) {
				InetAddress inet = null;
				try {
					inet = InetAddress.getLocalHost();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
				ip = inet.getHostAddress();
			}
		}

		if ((ip != null) && (ip.length() > 15) && (ip.indexOf(",") > 0)) {
			ip = ip.substring(0, ip.indexOf(","));
		}

		return ip;
	}
}
