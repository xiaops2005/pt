package com.viewhigh.vadp.framework.session.impl;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viewhigh.vadp.framework.session.BaseSessionStore;
import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionBasicInfo;
import com.viewhigh.vadp.framework.session.exception.SessionException;
import com.viewhigh.vadp.framework.session.util.SessionUtil;
import com.viewhigh.vadp.framework.session.util.SimpleStringUtil;
import com.viewhigh.vadp.framework.session.util.StringUtil;
import com.viewhigh.vadp.framework.util.RedisUtil;
import com.viewhigh.vadp.framework.util.SerializerUtil;

/**
 * 
 *  实现redis会话存储接口
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
@SuppressWarnings("unchecked")
public class RedisSessionStore extends BaseSessionStore {

	private Logger log = LoggerFactory.getLogger(RedisSessionStore.class);

	public static final String table_prefix = "viewhigh:session:table:";

	public Session createSession(SessionBasicInfo sessionBasicInfo) {
		String sessionid = this.randomToken();
		long creationTime = System.currentTimeMillis();
		long maxInactiveInterval = this.getSessionTimeout();
		long lastAccessedTime = creationTime;

		boolean isHttpOnly = StringUtil.hasHttpOnlyMethod() ? SessionUtil
				.getSessionManager().isHttpOnly() : false;
		boolean secure = SessionUtil.getSessionManager().isSecure();
		try {
			String sessionkey = getAPPSessionKey(sessionid);
			Map record = new HashMap();
			record.put(SerializerUtil.serial("sessionid"),
					SerializerUtil.serial(sessionid));
			record.put(SerializerUtil.serial("creationTime"),
					SerializerUtil.serial(creationTime + ""));
			record.put(SerializerUtil.serial("maxInactiveInterval"),
					SerializerUtil.serial(maxInactiveInterval + ""));
			record.put(SerializerUtil.serial("lastAccessedTime"),
					SerializerUtil.serial(lastAccessedTime + ""));
			record.put(SerializerUtil.serial("_validate"),
					SerializerUtil.serial(true + ""));
			//			record.put(SerializerUtil.serial("appKey"), SerializerUtil.serial(sessionBasicInfo.getAppKey()));
			record.put(SerializerUtil.serial("referip"),
					SerializerUtil.serial(sessionBasicInfo.getReferIP()));
			record.put(SerializerUtil.serial("host"),
					SerializerUtil.serial(SimpleStringUtil.getHostIP()));
			record.put(SerializerUtil.serial("requesturi"),
					SerializerUtil.serial(sessionBasicInfo.getRequestURI()));
			record.put(SerializerUtil.serial("lastAccessedUrl"),
					SerializerUtil.serial(sessionBasicInfo.getRequestURI()));
			record.put(SerializerUtil.serial("httpOnly"),
					SerializerUtil.serial(isHttpOnly + ""));
			record.put(SerializerUtil.serial("secure"),
					SerializerUtil.serial(secure + ""));
			record.put(SerializerUtil.serial("lastAccessedHostIP"),
					SerializerUtil.serial(SimpleStringUtil.getHostIP()));
			RedisUtil.hmset((byte[]) SerializerUtil.serial(sessionkey), record);

			Map attrRecord = new HashMap();
			attrRecord
					.put(SerializerUtil.serial(""), SerializerUtil.serial(""));
			String sessionAttrkey = sessionkey + ":attribute";
			RedisUtil.hmset((byte[]) SerializerUtil.serial(sessionAttrkey),
					attrRecord);

			if (maxInactiveInterval > 0) {
				RedisUtil.expire((byte[]) SerializerUtil.serial(sessionkey),
						maxInactiveInterval / 1000);
				RedisUtil.expire(
						(byte[]) SerializerUtil.serial(sessionAttrkey),
						maxInactiveInterval / 1000);
			}

			SimpleSessionImpl session = new SimpleSessionImpl();
			session.setMaxInactiveInterval(maxInactiveInterval);
			session.setCreationTime(creationTime);
			session.setLastAccessedTime(lastAccessedTime);
			session.setId(sessionid);
			session.setHost(SimpleStringUtil.getHostIP());
			session.setValidate(true);
			session.setRequesturi(sessionBasicInfo.getRequestURI());
			session.setLastAccessedUrl(sessionBasicInfo.getRequestURI());
			session.setSecure(secure);
			session.setHttpOnly(isHttpOnly);
			session.setLastAccessedHostIP(SimpleStringUtil.getHostIP());
			return session;
		} catch (Exception e) {
			log.error("", e);
		}
		return null;
	}

	public void addAttribute(HttpSession session, 
			String sessionID, String attribute, Object value) {
		try {
			String sessionKey = this.getAPPSessionAttributeKey(session.getId());
			if (value != null) {
				RedisUtil.hset((byte[]) SerializerUtil.serial(sessionKey),
						(byte[]) SerializerUtil.serial(attribute),
						(byte[]) value);
			} else {
				RedisUtil.hset((byte[]) SerializerUtil.serial(sessionKey),
						(byte[]) SerializerUtil.serial(attribute), null);
			}
		} catch (Exception e) {
			log.error("", e);
		}
	}

	public HttpSession createHttpSession(ServletContext servletContext,
			SessionBasicInfo sessionBasicInfo) {
		return null;
	}

	public Object getAttribute( String sessionID,
			String attribute) {
		String sessionkey = getAPPSessionAttributeKey(sessionID);
		try {
			byte[] value = RedisUtil.hget(
					(byte[]) SerializerUtil.serial(sessionkey),
					(byte[]) SerializerUtil.serial(attribute));
			if (value == null)
				return null;
			return SerializerUtil.unserial(value);
		} catch (Exception e) {
			log.error("", e);
		}

		return null;
	}

	public Enumeration getAttributeNames( String sessionID) {
		String[] names = getValueNames(sessionID);
		return SimpleStringUtil.arryToenum(names);
	}

	public long getLastAccessedTime(String sessionID) {
		String sessionKey = this.getAPPSessionKey(sessionID);
		try {
			byte[] lastAccessedTime = RedisUtil.hget(
					(byte[]) SerializerUtil.serial(sessionKey),
					(byte[]) SerializerUtil.serial("lastAccessedTime"));

			if (lastAccessedTime != null)
				return Long.parseLong((String) SerializerUtil
						.unserial(lastAccessedTime));

		} catch (Exception e) {
			log.error("", e);
		}
		return 0;
	}

	public Session getSession( String sessionid) {
		try {
			String sessionKey = this.getAPPSessionKey(sessionid);
			List<byte[]> fields = new ArrayList<byte[]>();
			fields.add((byte[]) SerializerUtil.serial("creationTime"));
			fields.add((byte[]) SerializerUtil.serial("maxInactiveInterval"));
			fields.add((byte[]) SerializerUtil.serial("lastAccessedTime"));
			fields.add((byte[]) SerializerUtil.serial("_validate"));
			fields.add((byte[]) SerializerUtil.serial("referip"));
			fields.add((byte[]) SerializerUtil.serial("host"));
			fields.add((byte[]) SerializerUtil.serial("requesturi"));
			fields.add((byte[]) SerializerUtil.serial("lastAccessedUrl"));
			fields.add((byte[]) SerializerUtil.serial("secure"));
			fields.add((byte[]) SerializerUtil.serial("httpOnly"));
			fields.add((byte[]) SerializerUtil.serial("lastAccessedHostIP"));

			byte[][] keys = new byte[fields.size()][];
			List<byte[]> values = RedisUtil.hmget(
					(byte[]) SerializerUtil.serial(sessionKey),
					fields.toArray(keys));
			if (values != null && values.get(0) != null) {
				SimpleSessionImpl session = new SimpleSessionImpl();
				session.setId(sessionid);
				session.setCreationTime(Long.parseLong((String) SerializerUtil
						.unserial(values.get(0))));
				session.setMaxInactiveInterval(Long
						.parseLong((String) SerializerUtil.unserial(values
								.get(1))));
				session.setLastAccessedTime(Long
						.parseLong((String) SerializerUtil.unserial(values
								.get(2))));
				session.setValidate(Boolean
						.parseBoolean((String) SerializerUtil.unserial(values
								.get(3))));
				session.setReferip((String) SerializerUtil.unserial(values
						.get(4)));

				session.setHost((String) SerializerUtil.unserial(values.get(5)));
				session.setRequesturi((String) SerializerUtil.unserial(values
						.get(6)));
				session.setLastAccessedUrl((String) SerializerUtil
						.unserial(values.get(7)));

				String secure_ = (String) SerializerUtil
						.unserial(values.get(8));
				if (secure_ != null) {
					session.setSecure(Boolean.parseBoolean(secure_));
				}
				String httpOnly_ = (String) SerializerUtil.unserial(values
						.get(9));
				if (httpOnly_ != null) {
					session.setHttpOnly(Boolean.parseBoolean(httpOnly_));
				} else {
					session.setHttpOnly(StringUtil.hasHttpOnlyMethod() ? SessionUtil
							.getSessionManager().isHttpOnly() : false);
				}
				session.setLastAccessedHostIP((String) SerializerUtil
						.unserial(values.get(10)));

				return session;
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("", e);
		}
		return null;
	}

	public String[] getValueNames( String sessionID) {
		String sessionKey = this.getAPPSessionAttributeKey(sessionID);
		String[] valueNames = null;
		try {
			Set<byte[]> keys = RedisUtil.hkeys((byte[]) SerializerUtil
					.serial(sessionKey));
			if (keys != null && keys.size() > 0) {
				Set<String> result = new HashSet<String>(keys.size());
				for (byte[] key : keys) {
					result.add((String) SerializerUtil.unserial(key));
				}
				valueNames = new String[keys.size()];
				valueNames = result.toArray(valueNames);
			}
		} catch (Exception e) {
			log.error("", e);
		}

		return valueNames;
	}

	public void invalidate(HttpSession session, 
			String sessionID) {
		String sessionKey = this.getAPPSessionKey(sessionID);
		String sessionAttributeKey = this.getAPPSessionAttributeKey(sessionID);
		try {
			RedisUtil.del((byte[]) SerializerUtil.serial(sessionKey),
					(byte[]) SerializerUtil.serial(sessionAttributeKey));
		} catch (Exception e) {
			log.error("", e);
		}
	}

	public boolean isNew(String sessionID) {
		String sessionKey = this.getAPPSessionKey(sessionID);
		try {
			List<byte[]> values = RedisUtil.hmget(
					(byte[]) SerializerUtil.serial(sessionKey),
					(byte[]) SerializerUtil.serial("lastAccessedTime"),
					(byte[]) SerializerUtil.serial("creationTime"));
			if (values == null || values.get(1) == null)
				throw new SessionException("SessionID[" + sessionID
						+ "] do not exist or is invalidated!");
			return values.get(0).equals(values.get(1));

		} catch (Exception e) {
			log.error("", e);
		}
		return false;
	}

	public void livecheck() {
		// TODO Auto-generated method stub
	}

	public void removeAttribute(HttpSession session, 
			String sessionID, String attribute) {
		String sessionKey = getAPPSessionAttributeKey(sessionID);
		try {
			RedisUtil.hdel((byte[]) SerializerUtil.serial(sessionKey),
					(byte[]) SerializerUtil.serial(attribute));
		} catch (Exception e) {
			log.error("", e);
		}
	}

	public void updateLastAccessedTime(String sessionID, long lastAccessedTime,
			String lastAccessedUrl, long maxInactiveInterval) {
		String sessionKey = this.getAPPSessionKey(sessionID);
		String sessionAttributeKey = this.getAPPSessionAttributeKey(sessionID);
		try {
			Map values = new HashMap();
			values.put(SerializerUtil.serial("lastAccessedTime"),
					SerializerUtil.serial(lastAccessedTime + ""));
			values.put(SerializerUtil.serial("lastAccessedUrl"),
					SerializerUtil.serial(lastAccessedUrl));
			values.put(SerializerUtil.serial("lastAccessedHostIP"),
					SerializerUtil.serial(SimpleStringUtil.getHostIP()));
			RedisUtil.hmset((byte[]) SerializerUtil.serial(sessionKey), values);
			RedisUtil.expire((byte[]) SerializerUtil.serial(sessionKey),
					maxInactiveInterval);
			RedisUtil.expire(
					(byte[]) SerializerUtil.serial(sessionAttributeKey),
					maxInactiveInterval);
		} catch (Exception e) {
			log.error("", e);
		}
	}

	public String getAPPSessionKey(String sessionid) {
		return new StringBuilder().append(table_prefix).append(":")
				.append(sessionid).toString();
	}

	public String getAPPSessionAttributeKey(String sessionid) {
		return new StringBuilder().append(getAPPSessionKey(sessionid))
				.append(":attribute").toString();
	}

}
