package com.viewhigh.vadp.framework.session.impl;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionBasicInfo;
import com.viewhigh.vadp.framework.session.SessionEvent;
import com.viewhigh.vadp.framework.session.SessionStore;
import com.viewhigh.vadp.framework.session.util.SessionUtil;
import com.viewhigh.vadp.framework.util.SerializerUtil;

/**
 * 
 * session存储的代理类，系统会在过滤器初始化init的时候，根据设定指定对应的存储实现类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class DelegateSessionStore implements SessionStore {
	private SessionStore sessionStore;

	public DelegateSessionStore(SessionStore sessionStore) {
		this.sessionStore = sessionStore;
	}

	public void destroy() {
		sessionStore.destroy();
	}

	public void livecheck() {
		sessionStore.livecheck();
	}

	public HttpSession createHttpSession(ServletContext servletContext,
			SessionBasicInfo sessionBasicInfo) {
		Session session = createSession(sessionBasicInfo);
		HttpSession httpsession = new HttpSessionImpl(session, servletContext);
		if (SessionUtil.haveSessionListener()) {
			SessionUtil.dispatchEvent(new SessionEventImpl(httpsession,
					SessionEvent.EventType_create));
		}
		return httpsession;
	}

	/**
	 * 调用指定的sessionStore的session创建接口创建出来session对象
	 */
	public Session createSession(SessionBasicInfo sessionBasicInfo) {
		Session session = sessionStore.createSession(sessionBasicInfo);
		if (session == null)
			return null;
		session._setSessionStore(this);
		session.putNewStatus();

		return session;
	}

	public Object getAttribute( String sessionID,
			String attribute) {
		return sessionStore.getAttribute( sessionID, attribute);
	}

	public Enumeration getAttributeNames( String sessionID) {
		return this.sessionStore.getAttributeNames( sessionID);
	}

	public void updateLastAccessedTime(String sessionID, long lastAccessedTime,
			String lastAccessedUrl, long maxInactiveInterval) {
		this.sessionStore.updateLastAccessedTime(sessionID, lastAccessedTime,
				lastAccessedUrl, maxInactiveInterval);

	}

	public long getLastAccessedTime(String sessionID) {
		return this.sessionStore.getLastAccessedTime(sessionID);
	}

	public String[] getValueNames( String sessionID) {
		return this.sessionStore.getValueNames( sessionID);
	}

	public void invalidate(HttpSession session, 
			String sessionID) {
		if (SessionUtil.haveSessionListener()) {
			SessionUtil.dispatchEvent(new SessionEventImpl(session,
					SessionEvent.EventType_destroy));
		}
		this.sessionStore.invalidate(session,  sessionID);

	}

	public boolean isNew(String sessionID) {

		return this.sessionStore.isNew(sessionID);
	}

	public void removeAttribute(HttpSession session, 
			String sessionID, String attribute) {
		if (SessionUtil.haveSessionListener()) {
			SessionUtil.dispatchEvent(new SessionEventImpl(session,
					SessionEvent.EventType_removeAttibute)
					.setAttributeName(attribute));
		}
		this.sessionStore.removeAttribute(session,  sessionID,
				attribute);

	}

	public void addAttribute(HttpSession session, 
			String sessionID, String attribute, Object value) {
		value = SerializerUtil.serial(value);
		this.sessionStore.addAttribute(session,  sessionID,
				attribute, value);

		if (SessionUtil.haveSessionListener()) {
			SessionUtil.dispatchEvent(new SessionEventImpl(session,
					SessionEvent.EventType_addAttibute)
					.setAttributeName(attribute));
		}
	}

	public void setSessionManager(SessionManager sessionManager) {
		this.sessionStore.setSessionManager(sessionManager);
	}

	public Session getSession( String sessionid) {
		Session session = this.sessionStore.getSession( sessionid);
		if (session != null)
			session._setSessionStore(this);
		return session;
	}
}
