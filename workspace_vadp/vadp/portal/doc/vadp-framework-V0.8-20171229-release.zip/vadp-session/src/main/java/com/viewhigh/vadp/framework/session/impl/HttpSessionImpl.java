package com.viewhigh.vadp.framework.session.impl;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import com.viewhigh.vadp.framework.session.Session;

/**
 * 
 * httpSession实现类，目的是从redis中取出后再还原成httpsession
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class HttpSessionImpl implements HttpSession {
	private Session session = null;
	private ServletContext servletContext;
//	private String contextpath;

	public HttpSessionImpl(Session session, ServletContext servletContext) {
		this.session = session;
		this.servletContext = servletContext;
//		this.contextpath = contextpath;
	}

	public Object getAttribute(String attribute) {
		return session.getAttribute(this, attribute);
	}

	public Enumeration getAttributeNames() {
		return this.session.getAttributeNames(this);
	}

	public long getCreationTime() {
		return this.session.getCreationTime();
	}

	public String getId() {
		return this.session.getId();
	}

	public void touch(String lastAccessedUrl) {
		session.touch(this, lastAccessedUrl);

	}

	public long getLastAccessedTime() {
		return this.session.getLastAccessedTime();
	}

	public int getMaxInactiveInterval() {
		return (int) session.getMaxInactiveInterval();
	}

	public Object getValue(String attribute) {
		return this.session.getValue(this, attribute);
	}

	public String[] getValueNames() {
		return session.getValueNames(this);
	}

	public void invalidate() {
		this.session.invalidate(this);

	}

	public boolean isNew() {
		return session.isNew();
	}

	public void putValue(String attribute, Object value) {
		session.putValue(this, attribute, value);
	}

	public void removeAttribute(String attribute) {
		session.removeAttribute(this, attribute);
	}

	public void removeValue(String attribute) {
		session.removeValue(this, attribute);
	}

	public void setAttribute(String attribute, Object value) {
		session.setAttribute(this, attribute, value);
	}

	public ServletContext getServletContext() {
		return this.servletContext;
	}

	public HttpSessionContext getSessionContext() {
		return null;
	}

	public void setMaxInactiveInterval(int arg0) {
		this.session.setMaxInactiveInterval(arg0);
	}

	public Session getInnerSession() {
		return this.session;
	}
}
