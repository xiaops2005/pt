package com.viewhigh.vadp.framework.session;

/**
 * 
 * 保存session的基本信息
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionBasicInfo {
	//	private String appKey;
	private String referIP;
	private String requestURI;
	private String lastAccessedHostIP;

	public SessionBasicInfo() {
	}

	public String getReferIP() {
		return referIP;
	}

	public void setReferIP(String referIP) {
		this.referIP = referIP;
	}

	public String getRequestURI() {
		return requestURI;
	}

	public void setRequestURI(String requestURI) {
		this.requestURI = requestURI;
	}

	public String getLastAccessedHostIP() {
		return lastAccessedHostIP;
	}

	public void setLastAccessedHostIP(String lastAccessedHostIP) {
		this.lastAccessedHostIP = lastAccessedHostIP;
	}

}
