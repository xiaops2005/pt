package com.viewhigh.vadp.framework.session.filter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionBasicInfo;
import com.viewhigh.vadp.framework.session.impl.HttpSessionImpl;
import com.viewhigh.vadp.framework.session.util.SessionUtil;
import com.viewhigh.vadp.framework.session.util.SimpleStringUtil;
import com.viewhigh.vadp.framework.session.util.StringUtil;

/**
 * 
 * http请求包装类，添加转化http请求为自定义请求的规则 版权所属：东软望海科技有限公司
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionHttpServletRequestWrapper extends HttpServletRequestWrapper {
	private String sessionID;
	private HttpSession session;
	private HttpServletResponse response;
	private ServletContext servletContext;

	public SessionHttpServletRequestWrapper(HttpServletRequest request,
			HttpServletResponse response, ServletContext servletContext) {
		super(request);
		sessionID = StringUtil.getCookieValue((HttpServletRequest) request,
				SessionUtil.getSessionManager().getCookieName());
		this.servletContext = servletContext;
		this.response = response;
	}

	public HttpSession getSession() {
		return getSession(true);
	}

	/**
	 * 重寫父类的方法，根据项目需要返回自定义session或httpsession
	 */
	public HttpSession getSession(boolean create) {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.getSession(create);
		}
		//当会话id为空的时候，就创建session对象，然后将sessionId放到cookie中
		if (sessionID == null) {
			SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
			sessionBasicInfo.setReferIP(SimpleStringUtil.getClientIp(this));
			sessionBasicInfo.setRequestURI(this.getRequestURI());
			this.session = SessionUtil.createSession(servletContext,
					sessionBasicInfo);
			sessionID = session.getId();
			SessionUtil.getSessionManager().setCookieName(sessionID);
			writeCookies();
			return this.session;
		} else if (session != null
				&& ((HttpSessionImpl) session).getInnerSession().isValidate()) {
			return session;
		} else {
			Session session = SessionUtil.getSession(sessionID);
			// session不存在，创建新的session
			if (session == null) {
				if (create) {
					SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
					sessionBasicInfo.setReferIP(SimpleStringUtil
							.getClientIp(this));
					sessionBasicInfo.setRequestURI(this.getRequestURI());
					this.session = (HttpSessionImpl) SessionUtil.createSession(
							servletContext, sessionBasicInfo);
					sessionID = this.session.getId();
					SessionUtil.getSessionManager().setCookieName(sessionID);
					writeCookies();
				}
			} else {
				this.session = new HttpSessionImpl(session, servletContext);
			}
			return this.session;
		}
	}

	public void touch() {
		if (SessionUtil.getSessionManager().useWebSession())
			return;
		if (this.sessionID != null) {
			if (session == null) {
				Session session_ = SessionUtil.getSession(sessionID);
				if (session_ == null || !session_.isValidate()) {
					this.sessionID = null;
					return;
				}
				this.session = new HttpSessionImpl(session_, servletContext);
			}
			if (session != null && !session.isNew()) {
				((HttpSessionImpl) session).touch(this.getRequestURI());
			}
		}
	}

	private void writeCookies() {
		boolean secure = SessionUtil.getSessionManager().isSecure();
		if (!this.isSecure())
			secure = false;
		StringUtil.addCookieValue(this, response, SessionUtil
				.getSessionManager().getCookieName(), sessionID, SessionUtil
				.getSessionManager().getCookieLiveTime(), SessionUtil
				.getSessionManager().isHttpOnly(), secure, SessionUtil
				.getSessionManager().getDomain());
	}

	public String getRequestedSessionId() {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.getRequestedSessionId();
		}
		if (this.sessionID != null)
			return sessionID;
		HttpSession session = this.getSession(false);
		if (session == null)
			return null;
		else
			return session.getId();
	}

	public boolean isRequestedSessionIdFromCookie() {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.isRequestedSessionIdFromCookie();
		}
		return true;
	}

	public boolean isRequestedSessionIdFromURL() {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.isRequestedSessionIdFromURL();
		}
		return false;
	}

	public boolean isRequestedSessionIdFromUrl() {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.isRequestedSessionIdFromUrl();
		}
		return false;
	}

	public boolean isRequestedSessionIdValid() {
		if (SessionUtil.getSessionManager().useWebSession()) {
			return super.isRequestedSessionIdValid();
		}
		HttpSessionImpl session = (HttpSessionImpl) this.getSession(false);
		if (session == null)
			return false;
		else
			return session.getInnerSession().isValidate();
	}

}
