package com.viewhigh.vadp.framework.session;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.impl.SessionManager;

/**
 * 
 * 存储session的接口
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public interface SessionStore {

	void destroy();

	void livecheck();

	public HttpSession createHttpSession(ServletContext servletContext,
			SessionBasicInfo sessionBasicInfo);

	public Session createSession(SessionBasicInfo sessionBasicInfo);

	public Object getAttribute( String sessionID,
			String attribute);

	public Enumeration getAttributeNames( String sessionID);

	public void updateLastAccessedTime(String sessionID, long lastAccessedTime,
			String lastAccessedUrl, long maxInactiveInterval);

	public long getLastAccessedTime(String sessionID);

	public String[] getValueNames( String sessionID);

	void invalidate(HttpSession session,  String sessionID);

	public boolean isNew(String sessionID);

	public void removeAttribute(HttpSession session, 
			String sessionID, String attribute);

	void addAttribute(HttpSession session, 
			String sessionID, String attribute, Object value);

	public void setSessionManager(SessionManager sessionManager);

	public Session getSession( String sessionid);

}
