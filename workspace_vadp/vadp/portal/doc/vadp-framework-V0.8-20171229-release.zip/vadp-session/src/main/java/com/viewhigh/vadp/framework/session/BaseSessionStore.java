package com.viewhigh.vadp.framework.session;

import java.util.UUID;

import com.viewhigh.vadp.framework.session.impl.SessionManager;

/**
 * 
 * 保存session的基本存储类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public abstract class BaseSessionStore implements SessionStore {

	protected SessionManager sessionManager;

	protected String randomToken() {
		String token = UUID.randomUUID().toString();
		return token;
	}

	public void destroy() {

	}

	public abstract Session createSession(SessionBasicInfo sessionBasicInfo);

	public long getSessionTimeout() {
		return sessionManager.getSessionTimeout();
	}

	public String getCookieName() {
		return sessionManager.getCookieName();
	}

	public boolean isHttpOnly() {
		return sessionManager.isHttpOnly();
	}

	public boolean isSecure() {
		return sessionManager.isSecure();
	}

	public long getCookieLiveTime() {
		return sessionManager.getCookieLiveTime();
	}

	public SessionManager getSessionManager() {
		return sessionManager;
	}

	public void setSessionManager(SessionManager sessionManager) {
		this.sessionManager = sessionManager;
	}

}
