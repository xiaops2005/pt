package com.viewhigh.vadp.framework.session.impl;

import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.SessionEvent;

/**
 * 
 * session事件接口
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionEventImpl implements SessionEvent {
	private HttpSession session;
	private String attributeName;

	private int eventType;

	public SessionEventImpl(HttpSession session, int eventType) {
		this.session = session;
		this.eventType = eventType;
	}

	public HttpSession getSource() {

		return session;
	}

	public int getEventType() {

		return eventType;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public SessionEventImpl setAttributeName(String attributeName) {
		this.attributeName = attributeName;
		return this;
	}

	public Object getAttributeValue() {
		return session.getAttribute(attributeName);
	}

}
