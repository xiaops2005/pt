package com.viewhigh.vadp.framework.session.util;

import java.lang.reflect.Method;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 处理请求中的字符串信息
 * 描述信息
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class StringUtil {

	private static Method httpOnlyMethod = null;
	static {
		try {
			httpOnlyMethod = Cookie.class.getMethod("setHttpOnly",
					boolean.class);
		} catch (Exception e) {

		}
	}

	public static boolean isEmpty(String value) {
		return value == null || "".equals(value);
	}

	public static boolean isNotEmpty(String value) {
		return value != null && !"".equals(value);
	}

	public static String getCookieValue(HttpServletRequest request,
			String cookieName) {
		return getCookieValue(request, cookieName, null);
	}

	public static String getCookieValue(HttpServletRequest request,
			String name, String defaultvalue) {
		if (name == null) {
			return null;
		}
		Cookie[] cookies = request.getCookies();
		if (cookies == null) {
			return defaultvalue;
		}
		String temp_ = null;
		for (Cookie temp : cookies) {
			if (name.equals(temp.getName())) {
				temp_ = temp.getValue();
				break;
			}
		}
		if (temp_ == null) {
			temp_ = defaultvalue;
		}
		return temp_;
	}

	public static void addCookieValue(HttpServletRequest request,
			HttpServletResponse response, String name, String value, int maxage) {
		addCookieValue(request, response, name, value, maxage, true);
	}

	public static void addCookieValue(HttpServletRequest request,
			HttpServletResponse response, String name, String value,
			int maxage, boolean httponly, boolean secure) {
		addCookieValue(request, response, name, value, maxage, httponly,
				secure, null);
	}

	public static boolean hasHttpOnlyMethod() {
		return httpOnlyMethod != null;
	}

	public static void addCookieValue(HttpServletRequest request,
			HttpServletResponse response, String name, String value,
			int maxage, boolean httponly, boolean secure, String domain) {
		addCookieValue(request, null, response, name, value, maxage, httponly,
				secure, domain);
	}

	public static void addCookieValue(HttpServletRequest request, String path,
			HttpServletResponse response, String name, String value,
			int maxage, boolean httponly, boolean secure, String domain) {
		try {
			if (path == null)
				path = request.getContextPath();
			if (path.equals(""))
				path = "/";
			Cookie loginPathCookie = null;
			loginPathCookie = new Cookie(name, value);
			loginPathCookie.setMaxAge(maxage);
			loginPathCookie.setPath(path);
			if (httpOnlyMethod != null) {
				httpOnlyMethod.invoke(loginPathCookie, httponly);

			}
			loginPathCookie.setSecure(secure);
			if (domain != null) {
				loginPathCookie.setDomain(domain);
			}
			response.addCookie(loginPathCookie);
		} catch (Throwable e) {

		}
	}

	public static void addCookieValue(HttpServletRequest request,
			HttpServletResponse response, String name, String value,
			int maxage, boolean httponly) {
		addCookieValue(request, response, name, value, maxage, httponly, false);
	}

	public static void addCookieValue(HttpServletRequest request,
			HttpServletResponse response, String name, String value) {
		addCookieValue(request, response, name, value, 3600 * 24);
	}

}
