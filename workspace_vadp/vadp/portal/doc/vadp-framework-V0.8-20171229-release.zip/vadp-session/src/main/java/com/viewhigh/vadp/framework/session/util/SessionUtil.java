package com.viewhigh.vadp.framework.session.util;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.viewhigh.vadp.framework.session.Session;
import com.viewhigh.vadp.framework.session.SessionBasicInfo;
import com.viewhigh.vadp.framework.session.SessionEvent;
import com.viewhigh.vadp.framework.session.impl.SessionManager;
import com.viewhigh.vadp.framework.util.SpringContextUtil;

/**
 * 
 * session操作的助手类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionUtil {
	private static SessionManager sessionManager = null;
	private static Object locked=new Object();
	public static SessionManager getSessionManager() {
		if (sessionManager == null) {
			synchronized (locked) {
				if (sessionManager == null) {

					sessionManager = (SessionManager) SpringContextUtil.getBean("distributedSessionManager");
				}
			}
		}
		return sessionManager;
	}

	public static boolean haveSessionListener() {
		return sessionManager.haveSessionListener();
	}

	public static void dispatchEvent(SessionEvent sessionEvent) {
		sessionManager.dispatchEvent(sessionEvent);
	}

	public static void writeCookies(HttpServletRequest request, HttpServletResponse response, String sessionID) {
		boolean secure = SessionUtil.getSessionManager().isSecure();
		if (!request.isSecure())
			secure = false;
		StringUtil.addCookieValue(request, response, SessionUtil.getSessionManager().getCookieName(), sessionID,
				SessionUtil.getSessionManager().getCookieLiveTime(), SessionUtil.getSessionManager().isHttpOnly(),
				secure, SessionUtil.getSessionManager().getDomain());
	}

	/**
	 * 根据代理的DelegateSessionStore创建出来httpsession对象
	 * @param servletContext
	 * @param sessionBasicInfo
	 * @return
	 */
	public static HttpSession createSession(ServletContext servletContext, SessionBasicInfo sessionBasicInfo) {
		HttpSession session = sessionManager.getSessionStore().createHttpSession(servletContext, sessionBasicInfo);
		return session;
	}

	/**
	 * 根据指定的sessionID返回对应的session对象
	 * @param sessionID
	 * @return
	 */
	public static Session getSession(String sessionID) {
		return sessionManager.getSessionStore().getSession(sessionID);
	}

	//	/**
	//	 * 根据指定的sessionID，request，response返回对应的session对象
	//	 * @param sessionID
	//	 * @param request
	//	 * @param response
	//	 * @return
	//	 */
	//	public static HttpSession getSession(String sessionID,
	//			HttpServletRequest request, HttpServletResponse response) {
	//		SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
	//		sessionBasicInfo.setReferIP(SimpleStringUtil.getClientIp(request));
	//		sessionBasicInfo.setRequestURI(request.getRequestURI());
	//		HttpSession session = SessionUtil.createSession(
	//				request.getServletContext(), sessionBasicInfo);
	//		sessionID = session.getId();
	//		SessionUtil.getSessionManager().setCookieName(sessionID);
	//		writeCookies(request, response, sessionID);
	//		return session;
	//	}

	//	public HttpSession getSession(String sessionID, HttpServletRequest request,
	//			HttpServletResponse response) {
	//		HttpSession session;
	//		if (SessionUtil.getSessionManager().useWebSession()) {
	//			session = request.getSession();
	//		} else {
	//			//当会话id为空的时候，就创建session对象，然后将sessionId放到cookie中
	//			if (sessionID == null) {
	//				SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
	//				sessionBasicInfo.setReferIP(SimpleStringUtil
	//						.getClientIp(request));
	//				sessionBasicInfo.setRequestURI(request.getRequestURI());
	//				session = SessionUtil.createSession(
	//						request.getServletContext(), sessionBasicInfo);
	//				sessionID = session.getId();
	//				SessionUtil.getSessionManager().setCookieName(sessionID);
	//				writeCookies(request, response, sessionID);
	//			} else {
	//				Session sessionInfo = getSession(sessionID);
	//				// session不存在，创建新的session
	//				if (sessionInfo == null) {
	//					SessionBasicInfo sessionBasicInfo = new SessionBasicInfo();
	//					sessionBasicInfo.setReferIP(SimpleStringUtil
	//							.getClientIp(request));
	//					sessionBasicInfo.setRequestURI(request.getRequestURI());
	//					session = (HttpSessionImpl) SessionUtil.createSession(
	//							request.getServletContext(), sessionBasicInfo);
	//					sessionID = session.getId();
	//					SessionUtil.getSessionManager().setCookieName(sessionID);
	//					writeCookies(request, response, sessionID);
	//				} else {
	//					session = new HttpSessionImpl(sessionInfo,
	//							request.getServletContext());
	//				}
	//
	//			}
	//		}
	//		return session;
	//	}
}
