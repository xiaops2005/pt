package com.viewhigh.vadp.framework.session.exception;

/**
 * 
 * session异常
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年5月31日
 * 修改日期: 2017年5月31日
 */
public class SessionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SessionException() {
		super();

	}

	public SessionException(String message, Throwable cause) {
		super(message, cause);

	}

	public SessionException(String message) {
		super(message);

	}

	public SessionException(Throwable cause) {
		super(cause);

	}

}
