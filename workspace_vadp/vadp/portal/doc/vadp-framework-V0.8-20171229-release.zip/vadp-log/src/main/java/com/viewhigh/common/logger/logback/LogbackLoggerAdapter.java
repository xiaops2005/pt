/**
 * Project Name:viewhigh-log
 * File Name:LogbackLoggerAdapter.java
 * Package Name:com.viewhigh.common.logger.logback
 * Date:2017年12月24日下午7:29:59
 * Copyright (c) 2017, wangting945@163.com All Rights Reserved.
 *
*/
package com.viewhigh.common.logger.logback;

import java.util.Iterator;

import com.viewhigh.common.logger.LoggerAdapter;
import com.viewhigh.vadp.log.Logger;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.FileAppender;

public class LogbackLoggerAdapter implements LoggerAdapter {
    
    private ch.qos.logback.classic.LoggerContext context = (LoggerContext) org.slf4j.LoggerFactory.getILoggerFactory();

	public LogbackLoggerAdapter() {
		try {
			ch.qos.logback.classic.Logger logger = context.getLogger("ROOT");
            if (logger != null) {
                Iterator<Appender<ILoggingEvent>> appenders = logger.iteratorForAppenders();
                if (appenders != null) {
                    while (appenders.hasNext()) {
                        Appender appender = appenders.next();
                        if (appender instanceof FileAppender) {
                            FileAppender fileAppender = (FileAppender)appender;
                            String filename = fileAppender.getFile();
                            break;
                        }
                    }
                }
            }
        } catch (Throwable t) {
        }
	}

	public Logger getLogger(Class<?> key) {
		return new LogbackLogger(context.getLogger(key));
	}

	public Logger getLogger(String key) {
		return  new LogbackLogger(context.getLogger(key));
	}

}