/**
 * Project Name:viewhigh-log
 * File Name:LogbackLogger.java
 * Package Name:com.viewhigh.common.logger.logback
 * Date:2017年12月24日下午7:29:59
 * Copyright (c) 2017, wangting945@163.com All Rights Reserved.
 *
*/
package com.viewhigh.common.logger.logback;

import com.viewhigh.vadp.log.Logger;

public class LogbackLogger implements Logger {

	private final org.slf4j.Logger logger;

	public LogbackLogger(org.slf4j.Logger logger) {
		this.logger = logger;
	}
	
	public void trace(String msg) {
		logger.trace(msg);
	}

	public void trace(Throwable e) {
		logger.trace(e.getMessage(), e);
	}

	public void trace(String msg, Throwable e) {
		logger.trace(msg, e);
	}
	
	public void trace(String format, Object arg) {
		logger.trace(format, arg);
	}
	
	public void trace(String format, Object... arguments) {
		logger.trace(format, arguments);
	}
	
	public void debug(String msg) {
		logger.debug(msg);
	}

	public void debug(Throwable e) {
		logger.debug(e.getMessage(), e);
	}

	public void debug(String msg, Throwable e) {
		logger.debug(msg, e);
	}
	
	public void debug(String format, Object arg) {
		logger.debug(format, arg);
	}
	
	public void debug(String format, Object... arguments) {
		logger.debug(format, arguments);
	}

	public void info(String msg) {
		logger.info(msg);
	}

	public void info(Throwable e) {
		logger.info(e.getMessage(), e);
	}

	public void info(String msg, Throwable e) {
		logger.info(e.getMessage(), e);
	}
	
	public void info(String format, Object arg) {
		logger.info(format, arg);
	}
	
	public void info(String format, Object... arguments) {
		logger.info(format, arguments);
	}
	
	public void warn(String msg) {
		logger.warn(msg);
	}

	public void warn(Throwable e) {
		logger.warn(e.getMessage(), e);
	}

	public void warn(String msg, Throwable e) {
		logger.warn(msg, e);
	}
	
	public void warn(String format, Object arg) {
		logger.warn(format, arg);
	}
	
	public void warn(String format, Object... arguments) {
		logger.warn(format, arguments);
	}

	public void error(String msg) {
		logger.error(msg);
	}

	public void error(Throwable e) {
		logger.error(e.getMessage(), e);
	}

	public void error(String msg, Throwable e) {
		logger.error(msg, e);
	}
	
	public void error(String format, Object arg) {
		logger.error(format, arg);
	}
	
	public void error(String format, Object... arguments) {
		logger.error(format, arguments);
	}
	
	public boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}
	
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	public boolean isInfoEnabled() {
		return logger.isInfoEnabled();
	}

	public boolean isWarnEnabled() {
		return logger.isWarnEnabled();
	}

	public boolean isErrorEnabled() {
		return logger.isErrorEnabled();
	}

}