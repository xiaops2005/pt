/**
 * Project Name:viewhigh-log
 * File Name:LoggerAdapter.java
 * Package Name:com.viewhigh.vadp.log
 * Date:2017年12月24日下午7:29:59
 * Copyright (c) 2017, wangting945@163.com All Rights Reserved.
 *
*/
package com.viewhigh.common.logger;

import com.viewhigh.vadp.log.Logger;


/**
 * 日志输出器供给器
 *
 * @author wangting
 */
public interface LoggerAdapter {
	
	/**
	 * 获取日志输出器
	 *
	 * @param key 分类键
	 * @return 日志输出器, 后验条件: 不返回null.
	 */
	Logger getLogger(Class<?> key);

	/**
	 * 获取日志输出器
	 *
	 * @param key 分类键
	 * @return 日志输出器, 后验条件: 不返回null.
	 */
	Logger getLogger(String key);
	
}