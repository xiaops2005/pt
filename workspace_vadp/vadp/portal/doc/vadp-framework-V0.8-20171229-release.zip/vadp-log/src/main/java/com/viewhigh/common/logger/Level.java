/**
 * Project Name:viewhigh-log
 * File Name:Level.java
 * Package Name:com.viewhigh.vadp.log
 * Date:2017年12月24日下午7:29:59
 * Copyright (c) 2017, wangting945@163.com All Rights Reserved.
 *
*/
package com.viewhigh.common.logger;

/**
 * Level
 * 
 * @author wangting
 */
public enum Level {

    /**
     * ALL
     */
	ALL,
	
	/**
     * DEBUG
     */
	DEBUG,
	
	/**
     * INFO
     */
	INFO,
	
	/**
     * WARN
     */
	WARN,
	
	/**
     * ERROR
     */
	ERROR,

	/**
     * OFF
     */
	OFF

}