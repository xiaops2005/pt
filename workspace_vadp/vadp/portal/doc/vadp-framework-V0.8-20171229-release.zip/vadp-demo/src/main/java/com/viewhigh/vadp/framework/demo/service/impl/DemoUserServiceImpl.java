package com.viewhigh.vadp.framework.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewhigh.vadp.framework.base.service.BaseServiceImpl;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.demo.repository.IDemoUserDao;
import com.viewhigh.vadp.framework.demo.service.IDemoUserService;

/**
 * 
 * 员工信息业务类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年6月5日
 * 修改日期: 2017年6月5日
 */
@Service("demoUserService")
public class DemoUserServiceImpl extends BaseServiceImpl implements IDemoUserService {

	@Autowired
	private IDemoUserDao demoUserDao;

	/* (non-Javadoc)
	 * @see com.viewhigh.vadp.framework.demo.service.impl.IDemoUserService#getDemoUser(java.lang.Object[])
	 */
	@Override
	public QueryResult getDemoUser(DemoUser user) {
		if (user != null) {
			return demoUserDao.getDemoUserByCondition(user);
		} else {
			return demoUserDao.getDemoAllUser();
		}

	}
}
