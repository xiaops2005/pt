package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_org")
public class DemoOrg {
	@Id
		@Column(name="ID")		
        private String id;
		@Column(name="description_ID")
		private String description;
		@Column(name="is_major_ID")
		private String isMajor;
		@Column (name="position_level")
		private String posionLevp;
		public String getPosionLevp() {
			return posionLevp;
		}
		public void setPosionLevp(String posionLevp) {
			this.posionLevp = posionLevp;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getIsMajor() {
			return isMajor;
		}
		public void setIsMajor(String isMajor) {
			this.isMajor = isMajor;
		}
   
   
}
	