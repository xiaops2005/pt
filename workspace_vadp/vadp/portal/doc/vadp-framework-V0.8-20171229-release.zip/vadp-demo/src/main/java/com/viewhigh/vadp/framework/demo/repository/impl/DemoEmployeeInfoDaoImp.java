package com.viewhigh.vadp.framework.demo.repository.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.demo.repository.IDemoEmployeeInfoDao;
@Repository
public  class DemoEmployeeInfoDaoImp extends BaseHibernateDAO implements IDemoEmployeeInfoDao{
	@Override
	public QueryResult getDemoUserByPage(String paramString,Object[] paramArrayOfObject, int currentNum, int pageNum){
		 QueryResult qr = new QueryResult();
	     qr.setPageSize(pageNum);
	     qr.setPageNumber(currentNum);
	     int recodecount=this.getTotalCount(paramString,paramArrayOfObject);
	     qr.setRecordCount(recodecount);
	     List<DemoUser> list=this.queryObjects(paramString,paramArrayOfObject,currentNum,pageNum);
	     qr.setResult(list);
		 return qr;
	}
	@Override
	public QueryResult findPage() {
		return this.queryObjectsByPage("from DemoUser", null);
	}
	@Override
	public QueryResult getAllUserByPage(Object[] paramArrayOfObject,int currentNum, int pageNum){
		 String hqlp="from DemoUser where id in (select isMajor from DemoOrg where description=? and (position_level=1 or position_level=2))";
		 QueryResult queryResult = new QueryResult();
		 queryResult.setPageSize(pageNum);
		 queryResult.setPageNumber(currentNum);
	     int recodecount=this.getTotalCount(hqlp,paramArrayOfObject);
	     List<DemoUser> list=this.queryObjects(hqlp,paramArrayOfObject,currentNum,pageNum);
	     queryResult.setResult(list);
	     queryResult.setRecordCount(recodecount);
	     return queryResult;

	}
}
