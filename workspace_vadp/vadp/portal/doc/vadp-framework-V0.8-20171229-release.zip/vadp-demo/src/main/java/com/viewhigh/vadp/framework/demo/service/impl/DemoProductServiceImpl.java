package com.viewhigh.vadp.framework.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewhigh.vadp.framework.base.service.BaseServiceImpl;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.repository.IDemoProductDao;
import com.viewhigh.vadp.framework.demo.service.IDemoProductService;

/**
 * 
 * 产品信息业务类
 * 版权所属：东软望海科技有限公司。
 * 作者：Bojc
 * 版本：V1.0
 * 创建日期：2017年6月5日
 * 修改日期: 2017年6月5日
 */
@Service("demoProductServiceImpl")
public class DemoProductServiceImpl extends BaseServiceImpl implements IDemoProductService{
	
	@Autowired
	private IDemoProductDao productDao;
	
	
	@Override
	public List getProductById(Long id) {
		return productDao.getProductById(id);
	}
	
	@Override
	public QueryResult findPage() {
		return productDao.findPage();
	}

	@Override
	public QueryResult findPageByFilter(String supplier, String standard,String company,String categoryId ,String sort,String sortName) {
		
		
		return productDao.findPageByFilter(supplier, standard,company,categoryId , sort, sortName);

	}
	
}
