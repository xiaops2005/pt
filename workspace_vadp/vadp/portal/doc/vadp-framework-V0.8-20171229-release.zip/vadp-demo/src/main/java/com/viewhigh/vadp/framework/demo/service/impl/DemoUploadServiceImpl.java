package com.viewhigh.vadp.framework.demo.service.impl;

import java.io.File;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.viewhigh.vadp.framework.demo.service.IDemoUploadService;
/**
 * 上传例子
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月19日
 * 修改日期: 2017年06月19日
 */
@Service("demoUploadServiceImpl")
@Transactional
public class DemoUploadServiceImpl implements IDemoUploadService {

	@Override
	public String upload(MultipartFile file, String id) {
		try {
			System.out.println(System.getProperty("web.root"));
			file.transferTo(new File(System.getProperty("web.root") + file.getOriginalFilename()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file.getOriginalFilename();
	}

}
