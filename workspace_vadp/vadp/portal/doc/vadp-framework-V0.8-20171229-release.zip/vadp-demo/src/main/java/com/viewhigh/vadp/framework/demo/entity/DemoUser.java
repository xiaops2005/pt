package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_user")
public class DemoUser {
	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "ACCOUNT")
	private String account;

	@Column(name = "NAME")
	private String name;

	@Column(name = "POSITION")
	private String position;

	@Column(name = "OUR_AAGE")
	private String ourAage;

	@Column(name = "RANK")
	private String rank;

	@Column(name = "EDUCATION")
	private String education;

	@Column(name = "SEX")
	private String sex;

	@Column(name = "BIRTHDATE")
	private String birthdate;

	@Column(name = "NATIONALITY")
	private String nationality;

	@Column(name = "CREDENTIALS_TYPE")
	private String credentialsType;

	@Column(name = "CREDENTIALS_NUMBER")
	private String credentialsNumber;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "IN_DATE")
	private String inDate;
	@Column(name = "pic_src")
	private String picSrc;

	public String getPicSrc() {
		return picSrc;
	}

	public void setPicSrc(String picSrc) {
		this.picSrc = picSrc;
	}

	@Transient
	private String sumBusiTripTime;
	@Transient
	private String sumHoliday;

	public String getSumBusiTripTime() {
		return sumBusiTripTime;
	}

	public void setSumBusiTripTime(String sumBusiTripTime) {
		this.sumBusiTripTime = sumBusiTripTime;
	}

	public String getSumHoliday() {
		return sumHoliday;
	}

	public void setSumHoliday(String sumHoliday) {
		this.sumHoliday = sumHoliday;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccount() {
		return this.account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getOurAage() {
		return this.ourAage;
	}

	public void setOurAage(String ourAage) {
		this.ourAage = ourAage;
	}

	public String getRank() {
		return this.rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getEducation() {
		return this.education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthdate() {
		return this.birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getCredentialsType() {
		return this.credentialsType;
	}

	public void setCredentialsType(String credentialsType) {
		this.credentialsType = credentialsType;
	}

	public String getCredentialsNumber() {
		return this.credentialsNumber;
	}

	public void setCredentialsNumber(String credentialsNumber) {
		this.credentialsNumber = credentialsNumber;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInDate() {
		return inDate;
	}

	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
}
