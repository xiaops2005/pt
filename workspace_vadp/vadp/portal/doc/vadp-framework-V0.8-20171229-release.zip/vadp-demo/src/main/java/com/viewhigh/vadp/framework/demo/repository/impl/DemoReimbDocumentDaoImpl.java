package com.viewhigh.vadp.framework.demo.repository.impl;

import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.demo.repository.IDemoReimbDocumentDao;

/**
 * 
 * 报销单Dao实现类
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月16日
 * 修改日期: 2017年06月16日
 */
@Repository
public class DemoReimbDocumentDaoImpl extends BaseHibernateDAO implements IDemoReimbDocumentDao {

}
