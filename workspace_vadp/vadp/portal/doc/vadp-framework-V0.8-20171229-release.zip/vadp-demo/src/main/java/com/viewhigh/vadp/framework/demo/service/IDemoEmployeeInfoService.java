package com.viewhigh.vadp.framework.demo.service;

import java.util.List;

import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;

public interface IDemoEmployeeInfoService{
  public QueryResult getDemoUserList(String usreId,Integer currentPage,Integer PageNum);
  public List<DemoUser> getAll();
  public QueryResult findPage();
  //获取所有下级
  public QueryResult getDemoUserListAll(String usreId, Integer currentPage,Integer PageNum);
}
