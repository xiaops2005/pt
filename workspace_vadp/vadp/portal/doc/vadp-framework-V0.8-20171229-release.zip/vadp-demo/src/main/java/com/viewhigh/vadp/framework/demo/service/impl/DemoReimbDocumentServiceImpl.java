package com.viewhigh.vadp.framework.demo.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewhigh.vadp.framework.base.service.BaseServiceImpl;
import com.viewhigh.vadp.framework.demo.entity.DemoReimbDocument;
import com.viewhigh.vadp.framework.demo.entity.DemoReimbDocumentDetail;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.demo.repository.IDemoReimbDocumentDao;
import com.viewhigh.vadp.framework.demo.service.IDemoReimbDocumentService;
import com.viewhigh.vadp.framework.ds.BOContext;
import com.viewhigh.vadp.framework.util.UUIDGenerater;

/**
 * 
 * 报销单业务类接口实现
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月16日
 * 修改日期: 2017年06月16日
 */
@Service("demoReimbDocumentServiceImpl")
public class DemoReimbDocumentServiceImpl extends BaseServiceImpl implements IDemoReimbDocumentService {
	
	@Autowired
	private IDemoReimbDocumentDao dao;

	/**
	 * 
	 * @Title: findList   
	 * @Description: 获取报销单列表  
	 * @param: @param title 标题
	 * @param: @return      
	 * @return: List<DemoReimbDocument>      
	 * @throws
	 */
	@Override
	public List<DemoReimbDocument> findList(String title) {
		String hql = " from DemoReimbDocument ";
		if(StringUtils.isNotBlank(title)){
			hql += " where name like '" + title + "%'";
		}
		return dao.queryObjects(hql);
	}

	/**
	 * 
	 * @Title: findByInfo   
	 * @Description: 获取报销单全部信息
	 * @param: @param id
	 * @param: @return      
	 * @return: BOContext      
	 * @throws
	 */
	@Override
	public BOContext findByInfo(String id) {
		BOContext dc = new BOContext();
		dc.set("result", dao.queryObject("from DemoReimbDocument where id = ?", id));
		dc.set("details", findDetails(id));
		return dc ;
	}

	/**
	 * 
	 * @Title: findByUserList   
	 * @Description: 获取用户列表
	 * @param: @return      
	 * @return: List<DemoUser>      
	 * @throws
	 */
	@Override
	public List<DemoUser> findByUserList() {
		return dao.queryObjects("from DemoUser");
	}

	/**
	 * 
	 * @Title: findDetails   
	 * @Description: 获取报销单详情列表 
	 * @param: @param id
	 * @param: @return      
	 * @return: List<DemoReimbDocumentDetail>      
	 * @throws
	 */
	@Override
	public List<DemoReimbDocumentDetail> findDetails(String id) {
		return dao.queryObjects("from DemoReimbDocumentDetail where document.id = ?", id);
	}

	/**
	 * 
	 * @Title: save   
	 * @Description: 保存报销单
	 * @param: @param model
	 * @param: @param list
	 * @param: @return      
	 * @return: DemoReimbDocument      
	 * @throws
	 */
	@Override
	public DemoReimbDocument save(DemoReimbDocument model,List<DemoReimbDocumentDetail> list) {
		if (StringUtils.isBlank(model.getId())) {
			model.setId(UUIDGenerater.generateId());
			String id = (String) dao.addObject(model);
			saveDetails(model, list);
			return (DemoReimbDocument) dao.queryObject("from DemoReimbDocument where id = ?", id);
		} else {
			dao.update("delete from demo_reimb_document_detail where document_ID = ?", new Object[]{ model.getId() });
			saveDetails(model, list);
			dao.updateObject(model);
		}
		return model;
	}

	/**
	 * 
	 * @Title: save   
	 * @Description: 保存报销单详细信息
	 * @param: @param model
	 * @param: @param list
	 * @param: @return      
	 * @return: DemoReimbDocument      
	 * @throws
	 */
	public void saveDetails(DemoReimbDocument model, List<DemoReimbDocumentDetail> list) {
		if (list != null) {
			for (DemoReimbDocumentDetail bean : list) {
				if (StringUtils.isBlank(bean.getId())) {
					bean.setId(UUIDGenerater.generateId());
				}
				bean.setDocument(model);
				bean.setUser(null);
			}
			dao.addOrUpdateObjects(list);
		}
	}
	
}
