package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_product")
public class DemoProduct {

	
	
		@Id
		@Column(name="ID")		
        private String id;
        
		@Column(name="IS_MAJOR")		
        private String isMajor;
        
		@Column(name="DESCRIPTION")		
        private String description;
        
		@Column(name="CREATOR")		
        private String creator;
        
		@Column(name="CREATION_DATE")		
        private String creationDate;
        
		@Column(name="LAST_UPDATOR")		
        private String lastUpdator;
        
		@Column(name="OVERDUE")		
        private String overdue;
        
		@Column(name="NUMs")		
        private String nUMs;
        
	    public String getId() {
		 return this.id;
	    }
		public void setId(String id) {
			this.id = id;
		}
		
	    public String getIsMajor() {
		 return this.isMajor;
	    }
		public void setIsMajor(String isMajor) {
			this.isMajor = isMajor;
		}
		
	    public String getDescription() {
		 return this.description;
	    }
		public void setDescription(String description) {
			this.description = description;
		}
		
	    public String getCreator() {
		 return this.creator;
	    }
		public void setCreator(String creator) {
			this.creator = creator;
		}
		
	    public String getCreationDate() {
		 return this.creationDate;
	    }
		public void setCreationDate(String creationDate) {
			this.creationDate = creationDate;
		}
		
	    public String getLastUpdator() {
		 return this.lastUpdator;
	    }
		public void setLastUpdator(String lastUpdator) {
			this.lastUpdator = lastUpdator;
		}
		
	    public String getOverdue() {
		 return this.overdue;
	    }
		public void setOverdue(String overdue) {
			this.overdue = overdue;
		}
		
	    public String getNUMs() {
		 return this.nUMs;
	    }
		public void setNUMs(String nUMs) {
			this.nUMs = nUMs;
		}
		
}
	