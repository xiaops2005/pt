package com.viewhigh.vadp.framework.demo.service;

import java.util.List;
import java.util.Map;

import com.viewhigh.vadp.framework.demo.entity.DemoSysUser;

public interface IDemoService {
	
	public void system();
	
	public String sayHello();
	
	public String sayHello(String userName);
	
	public String sayHello(String userName,Integer age);
	
	public String sayHello(Map<String,String> datas,String userName);
	
	public List<Map<String, String>> sayHello(List<Map<String, String>> list, String userName);
	
	public String sayHello(DemoSysUser user);
	
	public List<DemoSysUser> sayHello(List<DemoSysUser> users);
	
	public List<String> getIdList(List<Integer> idList);
	
	public DemoSysUser getSysUser(Map<String,String> datas,String userName);

}
