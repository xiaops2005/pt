package com.viewhigh.vadp.framework.demo.exception;

import com.viewhigh.vadp.framework.exception.ServiceException;
/**
 * 
 * 测试自定义异常
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月26日
 * 修改日期: 2017年06月26日
 */
public class DemoException extends ServiceException {

	public DemoException(String paramString, String[] paramArrayOfString) {
		super(paramString, paramArrayOfString);
	}
	
	public DemoException(String paramString, Throwable paramThrowable, String[] paramArrayOfString) {
		super(paramString, paramThrowable, paramArrayOfString);
	}

}
