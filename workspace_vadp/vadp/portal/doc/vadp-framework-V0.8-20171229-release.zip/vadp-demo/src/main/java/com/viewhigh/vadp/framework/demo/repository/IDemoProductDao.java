package com.viewhigh.vadp.framework.demo.repository;

import java.util.List;

import com.viewhigh.vadp.framework.data.base.dao.IBaseDao;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;

public interface IDemoProductDao extends IBaseDao {
	
	public List getProductById(Long id);

	public QueryResult findPage();
	
	public QueryResult findPageByFilter(String supplier,String standard,String company,String categoryId,String sort,String sortName);

}
