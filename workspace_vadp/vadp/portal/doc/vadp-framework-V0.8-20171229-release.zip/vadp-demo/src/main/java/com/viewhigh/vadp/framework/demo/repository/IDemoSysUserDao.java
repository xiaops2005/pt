package com.viewhigh.vadp.framework.demo.repository;

import java.util.List;

import com.viewhigh.vadp.framework.data.base.dao.IBaseDao;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;

public interface IDemoSysUserDao extends IBaseDao {
	
	public List getUserById(Long id);

	public QueryResult findPage();

	public void save();
}
