package com.viewhigh.vadp.framework.demo.service;

import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;

public interface IDemoUserService {

	public abstract QueryResult getDemoUser(DemoUser user);

}