package com.viewhigh.vadp.framework.demo.service;

import java.util.List;

import net.sf.json.JSONObject;

import com.viewhigh.vadp.framework.base.IBaseService;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoDemission;


public interface IDemoDemissionService extends IBaseService {
	
	public List getDemissionById(String id);
	
	public QueryResult findPage();
	
	public DemoDemission save(DemoDemission model);
	
	public DemoDemission edit(DemoDemission model);
	
	public Boolean del(String id);
	
	public JSONObject findList(String org,String year,String quarter,String month);
	public String chart1(String org, String year, String quarter,String month,String date,String dateSql);
	public JSONObject chart2(String org, String year, String quarter,String month,String date);
	public JSONObject chart3(String org, String year, String quarter,String month,String dateSql,String demissionSql);
	public JSONObject chart4(String org, String year, String quarter,String month,String dateSql,String demissionSql);
}