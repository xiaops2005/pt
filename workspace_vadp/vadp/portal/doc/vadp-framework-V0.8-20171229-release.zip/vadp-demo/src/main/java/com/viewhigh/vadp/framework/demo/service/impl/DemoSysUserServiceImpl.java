//package com.viewhigh.vadp.framework.demo.service.impl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import com.viewhigh.vadp.framework.base.service.BaseServiceImpl;
//import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
//import com.viewhigh.vadp.framework.demo.entity.DemoSysUser;
//import com.viewhigh.vadp.framework.demo.repository.IDemoSysUserDao;
//import com.viewhigh.vadp.framework.demo.repository.IDemoSysUserRepository;
//import com.viewhigh.vadp.framework.demo.service.IDemoSysUserService;
//import com.viewhigh.vadp.framework.ds.BOContext;
//import com.viewhigh.vadp.framework.util.RequestContextUtil;
//
//@Service("demoSysUserServiceImpl")
//public class DemoSysUserServiceImpl extends BaseServiceImpl implements IDemoSysUserService {
//
//	@Autowired
//	private IDemoSysUserRepository dao;
//	@Autowired
//	private IDemoSysUserDao userDao;
//
//	@Value("${name:World}")
//	private String name;
//
//	@Override
//	public List getUserById(Long id) throws Exception {
//		return userDao.getUserById(id);
//	}
//
//	@Override
//	public QueryResult findPage() {
//		return userDao.findPage();
//	}
//
//	@Override
//	public DemoSysUser save(DemoSysUser model) throws Exception {
//		userDao.save();
//		Long id = (Long) userDao.addObject(model);
//		if(true){
//			throw new RuntimeException("111");
//		}
//		return (DemoSysUser) userDao.getUserById(id).get(0);
//	}
//
//	@Override
//	public DemoSysUser edit(DemoSysUser model) {
//		userDao.updateObject(model);
//		return (DemoSysUser) userDao.getUserById(model.getId()).get(0);
//	}
//
//	@Override
//	public Boolean del(Long id) {
//		userDao.update("delete from sys_user where id = ? ", new Object[] { id });
//		return true;
//	}
//
//	@Override
//	public QueryResult queryDs1() throws Exception {
//		userDao.save();
//		if(true){
//			throw new RuntimeException("queryDs1 Exception");
//		}
//		return userDao.query("select database()", null);
//	}
//	
//	
//	@Override
//	public QueryResult queryDs2() {
//		return userDao.query("select database()", null);
//	}
//
//	
//	@Override
//	public QueryResult queryDs3() {
//		return userDao.query("select database()", null);
//	}
//
//	@Override
//	public BOContext testException() {
//		BOContext bo = new BOContext();
//		bo.set("bo2", new BOContext());
//		return bo;
//	}
//
//	@Override
//	public String getCode() {
//		return (String)RequestContextUtil.getRequest().getSession().getAttribute("_captchaCode");
//	}
//}