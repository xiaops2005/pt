package com.viewhigh.vadp.framework.demo.service;


import java.util.List;

import com.viewhigh.vadp.framework.base.IBaseService;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoSysUser;
import com.viewhigh.vadp.framework.ds.BOContext;


public interface IDemoSysUserService extends IBaseService {
	
	public List getUserById(Long id)  throws Exception;
	
	public QueryResult findPage();
	
	public DemoSysUser save(DemoSysUser model) throws Exception;
	
	public DemoSysUser edit(DemoSysUser model) throws Exception;
	
	public Boolean del(Long id);
	
	public QueryResult queryDs1() throws Exception;
	
	public QueryResult queryDs2() ;
	
	public QueryResult queryDs3();
	
	public BOContext testException();
	
	public String getCode();
	
}