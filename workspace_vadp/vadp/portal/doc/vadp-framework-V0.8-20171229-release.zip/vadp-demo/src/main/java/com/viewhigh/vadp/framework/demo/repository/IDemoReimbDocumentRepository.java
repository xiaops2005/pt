package com.viewhigh.vadp.framework.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.viewhigh.vadp.framework.demo.entity.DemoReimbDocument;
/**
 * 
 * 报销单JPA
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月16日
 * 修改日期: 2017年06月16日
 */
public interface IDemoReimbDocumentRepository extends CrudRepository<DemoReimbDocument, String> {

}
