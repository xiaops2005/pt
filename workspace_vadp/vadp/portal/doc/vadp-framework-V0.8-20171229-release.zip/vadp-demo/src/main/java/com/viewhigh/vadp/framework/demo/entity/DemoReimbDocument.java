package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。 作者：作者 版本：V1.0 创建日期：Apr 16, 2017 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_reimb_document")
public class DemoReimbDocument {

	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REMARK")
	private String remark;

	@Column(name = "REIMBURSEMENT_AMOUNT")
	private String reimbursementAmount;

	@Column(name = "WRITE_DOWN_AMOUNT")
	private String writeDownAmount;

	@Column(name = "APPLY_DATE")
	private String applyDate;

	@Column(name = "MATTER")
	private String matter;

	@Column(name = "REASON")
	private String reason;

	@Column(name = "DEPTID")
	private String deptId;

	@ManyToOne(targetEntity = DemoUser.class)
	@JoinColumn(name = "USER_ID")
	private DemoUser user;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReimbursementAmount() {
		return this.reimbursementAmount;
	}

	public void setReimbursementAmount(String reimbursementAmount) {
		this.reimbursementAmount = reimbursementAmount;
	}

	public String getWriteDownAmount() {
		return this.writeDownAmount;
	}

	public void setWriteDownAmount(String writeDownAmount) {
		this.writeDownAmount = writeDownAmount;
	}

	public String getApplyDate() {
		return this.applyDate;
	}

	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}

	public String getMatter() {
		return this.matter;
	}

	public void setMatter(String matter) {
		this.matter = matter;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public DemoUser getUser() {
		return this.user;
	}

	public void setUser(DemoUser user) {
		this.user = user;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	
	

}
