package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_annual_rating")
public class DemoAnnualRating {
		@Id
		@Column(name="ID")		
        private String id;
		@Column(name="ANNUAL")		
        private String annual;
		@Column(name="RES")		
        private String res;
		@Column(name="user_ID")	
		private String userId;
	    public String getId() {
		 return this.id;
	    }
		public void setId(String id) {
			this.id = id;
		}
		
	    public String getAnnual() {
		 return this.annual;
	    }
		public void setAnnual(String annual) {
			this.annual = annual;
		}
		
	    public String getRes() {
		 return this.res;
	    }
		public void setRes(String res) {
			this.res = res;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId){
			this.userId = userId;
		}   
}
	