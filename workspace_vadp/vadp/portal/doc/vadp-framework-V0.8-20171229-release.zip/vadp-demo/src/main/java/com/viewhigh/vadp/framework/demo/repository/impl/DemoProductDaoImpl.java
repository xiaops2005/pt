package com.viewhigh.vadp.framework.demo.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.repository.IDemoProductDao;
/**
 * 
 * 对产品信息进行持久化的类
 * 版权所属：东软望海科技有限公司。
 * 作者：Bojc
 * 版本：V1.0
 * 创建日期：  2017年6月16日
 * 修改日期: 2017年6月16日
 */

@Repository
public class DemoProductDaoImpl extends BaseHibernateDAO implements IDemoProductDao{
	@Override
	public List getProductById(Long id) {
		return this.queryObjects("from DemoProduct where id = ?", id);
	}

	@Override
	public QueryResult findPage() {
		return this.queryObjectsByPage("from DemoProduct ", null);
	}
	
	@Override
	public QueryResult findPageByFilter(String supplier,String standard,String company,String categoryId,String sort,String sortName) {
		String strSql="from DemoProduct where 1=1 ";
		List<Object> params = new ArrayList<Object>();
		if(!supplier.isEmpty()){
			strSql+=" and CREATOR like ?";
			params.add("%"+supplier+"%");
		}
		if(!standard.isEmpty()){
			strSql+=" and (OVERDUE like ? or DESCRIPTION like ?)";
			params.add("%"+standard+"%");
			params.add("%"+standard+"%");
		}
		if(!company.isEmpty()){
			strSql+=" and CREATION_DATE like ?";
			params.add("%"+company+"%");
		}
		if(!categoryId.isEmpty()){
			strSql+=" and LAST_UPDATOR=?";
			params.add(categoryId);
		}
		if(sort!=null&&!sort.isEmpty()){
			strSql+=" order by ?";
			params.add(sortName+" "+ sort);
		}
		return this.queryObjectsByPage(strSql, params.toArray());
	}
}
