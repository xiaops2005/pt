package com.viewhigh.vadp.framework.demo.service.impl;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.viewhigh.vadp.framework.base.service.BaseServiceImpl;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoDemission;
import com.viewhigh.vadp.framework.demo.repository.DemoDemissionDao;
import com.viewhigh.vadp.framework.demo.service.IDemoDemissionService;

@Service("demoDemissionServiceImpl")
@Transactional
public class DemoDemissionServiceImpl extends BaseServiceImpl implements IDemoDemissionService{
	

 	@Autowired
 	private  DemoDemissionDao demoDemissionDao;
 	
	@Override
	public List getDemissionById(String id) {
		return demoDemissionDao.getDemissionById(id);
	}

	@Override
	public QueryResult findPage() {
		return demoDemissionDao.findPage();
	}

	@Override
	public DemoDemission save(DemoDemission model) {
		String id = (String) demoDemissionDao.addObject(model);
		return (DemoDemission) demoDemissionDao.getDemissionById(id).get(0);
	}

	@Override
	public DemoDemission edit(DemoDemission model) {
		demoDemissionDao.updateObject(model);
		return (DemoDemission) demoDemissionDao.getDemissionById(model.getId()).get(0);
	}

	@Override
	public Boolean del(String id) {
		demoDemissionDao.update("delete from demo_demission where id = ? ", new Object[] { id });
		return true;
	}
	
	@Override
	public String chart1(String org, String year, String quarter,String month,String date,String dateSql) {
		
		int out = demoDemissionDao.out(date, org);
		int in = demoDemissionDao.chart1In(dateSql,org);
		double rate = 0;
		if(in != 0){
			rate = (double)(out*100)/in;
			//System.out.println(rate);
		}
		String myrate = new java.text.DecimalFormat("#.00").format(rate);

		return myrate;
	}

	@Override
	public JSONObject chart2(String org, String year, String quarter,String month,String date) {
		JSONObject json = new JSONObject();
		List<String> nameList = new ArrayList();
		JSONArray dataArr = new JSONArray();
			
		String[] legend={"工作压力","薪资福利","职业发展","个人原因","外部环境"};
		
		 List list = demoDemissionDao.chart2List(date, org);
		 for(int i=0;i<list.size();i++){
			 JSONObject js = new JSONObject();
			 Object[] obj = (Object[])list.get(i);
			 //System.out.println(obj[0]);
			 //System.out.println(obj[1]);
			 String name=legend[Integer.parseInt(""+obj[0])-1];
			 nameList.add(name);
			 js.put("name",name);
			 js.put("value", Integer.parseInt(""+obj[1]));
			 dataArr.add(js);			
		 }
		 for(int i=0;i<legend.length;i++){
			 boolean flag=true;
			 for(int j=0;j<nameList.size();j++){
				 if(legend[i].equals(nameList.get(j))){
					 flag=false;
					 break;
				 }
			 }
			 if(flag==true){
				 JSONObject js = new JSONObject();				
				 js.put("name",legend[i]);
				 js.put("value", 0);
				 dataArr.add(js); 
			 }
		 }
		json.put("dataArr", dataArr);         
		return json;
	}

	@Override
	public JSONObject chart3(String org, String year, String quarter,String month,String dateSql,String demissionSql) {
		JSONObject json = new JSONObject();
		JSONArray dataListArr = new JSONArray();		
		JSONArray seriesArr = new JSONArray();
			
		String[] legend={"研究生","大学本科","大专和专科学校","中专和中技","技工学校","无学历数据"};
		List list = demoDemissionDao.chart3LegendList(dateSql, org,demissionSql);
		String[] xAxis=new String[list.size()];
		 for(int i=0;i<list.size();i++){
			 JSONObject js = new JSONObject();
			 Object obj = (Object)list.get(i);
			 //System.out.println(obj);
			 xAxis[i]=(""+obj);		 			
		 }
		 for(int k=0;k<legend.length;k++){
			 List<String> nameList = new ArrayList();
			 JSONArray dataArr = new JSONArray();
			 list = demoDemissionDao.chart3DataList(k, dateSql, org,demissionSql);
			 for(int i=0;i<list.size();i++){
				 JSONObject js = new JSONObject();
				 Object[] obj = (Object[])list.get(i);;
				 String name=""+obj[0];
				 nameList.add(name);
				 js.put("name",""+name);
				 js.put("value", Integer.parseInt(""+obj[1]));
				 dataArr.add(js);			
			 }
			 for(int i=0;i<xAxis.length;i++){//补xAxis没有查到人数为0
				 boolean flag=true;
				 for(int j=0;j<nameList.size();j++){
					 if(xAxis[i].equals(nameList.get(j))){
						 flag=false;
						 break;
					 }
				 }
				 if(flag==true){
					 JSONObject js = new JSONObject();				
					 js.put("name",xAxis[i]);
					 js.put("value", 0);
					 dataArr.add(js); 
				 }
			 }
			 dataListArr.add(dataArr);
		 }
		 
		 for(int k=0;k<legend.length;k++){
			 Integer[] dataList = new Integer[xAxis.length];
			 for(int i=0;i<xAxis.length;i++){//数据按xAxis排序	
				 JSONArray arr =(JSONArray)dataListArr.get(k);
				 for(int j=0;j<arr.size();j++){	
					 JSONObject jo =(JSONObject)arr.get(j);
					 if(xAxis[i].equals(""+jo.get("name"))){
						 dataList[i]=(Integer.parseInt(""+jo.get("value")));
						 break;
					 } 
				 }			 
			 }
			 JSONObject seriesJs = new JSONObject();
			 seriesJs.put("name",legend[k]);
			 seriesJs.put("type", "bar");
			 seriesJs.put("barWidth", 20);
			 seriesJs.put("stack", "学历");
			 seriesJs.put("data",dataList);
			 seriesArr.add(seriesJs);
		 }
		 json.put("xAxis",xAxis);
		 json.put("seriesArr", seriesArr);       
		return json;
	}

	@Override
	public JSONObject chart4(String org, String year, String quarter,String month,String dateSql,String demissionSql) {
		JSONObject json = new JSONObject();
		JSONArray dataListArr = new JSONArray();		
		JSONArray seriesArr = new JSONArray();
	
		String[] legend={"30岁以下","30岁(含)-40岁","40岁(含)-50岁","50岁以上"};
		String[] legendSql={"<30","between 30 and 40","between 40 and 50",">=50"};
		List list = demoDemissionDao.chart4AxisList(dateSql, org,demissionSql);
		String[] xAxis=new String[list.size()];
		Integer[] sumList=new Integer[list.size()];
		Double[] lineList=new Double[list.size()];
		 for(int i=0;i<list.size();i++){
			 JSONObject js = new JSONObject();
			 Object[] obj = (Object[])list.get(i);
			 xAxis[i]=(""+obj[0]);
			 sumList[i]=(Integer.parseInt(""+obj[1]));
			 lineList[i]=(Double.parseDouble(""+obj[2]));
		 }
		 JSONObject sumJs = new JSONObject();
		 sumJs.put("name","总数");
		 sumJs.put("type", "bar");
		 sumJs.put("barWidth", 20);		
		 sumJs.put("data",sumList);
		 seriesArr.add(sumJs);
		 		 
		 for(int k=0;k<legend.length;k++){
			 JSONArray dataArr = new JSONArray();
			 String lSql = legendSql[k];
			 list = demoDemissionDao.chart4DataList(lSql, dateSql, org,demissionSql);
			 List<String> nameList = new ArrayList();
			 for(int i=0;i<list.size();i++){
				 JSONObject js = new JSONObject();
				 Object[] obj = (Object[])list.get(i);;
				 String name=""+obj[0];
				 nameList.add(name);
				 js.put("name",""+name);
				 js.put("value", Integer.parseInt(""+obj[1]));
				 dataArr.add(js);			
			 }
			 //System.out.println("nameList:"+nameList.size());
			 //System.out.println("1:"+dataArr.size());
			 
			 for(int i=0;i<xAxis.length;i++){//补xAxis没有查到部门人数为0
				 
				 boolean flag=true;
				 //System.out.println("3:"+nameList.size());
				 for(int j=0;j<nameList.size();j++){
					 //System.out.println(nameList.get(j));
					 if(xAxis[i].equals(nameList.get(j))){
						 flag=false;
						 break;
					 }
				 }
				 if(flag==true){
					 JSONObject js = new JSONObject();				
					 js.put("name",xAxis[i]);
					 js.put("value", 0);
					 dataArr.add(js); 
				 }
			 }
			 dataListArr.add(dataArr);
		 }
		 
		 for(int k=0;k<legend.length;k++){
			 Integer[] dataList = new Integer[xAxis.length];
			 for(int i=0;i<xAxis.length;i++){//数据按xAxis排序	
				 JSONArray arr =(JSONArray)dataListArr.get(k);
				 for(int j=0;j<arr.size();j++){	
					 JSONObject jo =(JSONObject)arr.get(j);
					 if(xAxis[i].equals(""+jo.get("name"))){
						 dataList[i]=(Integer.parseInt(""+jo.get("value")));
						 break;
					 } 
				 }			 
			 }
			 JSONObject seriesJs = new JSONObject();
			 seriesJs.put("name",legend[k]);
			 seriesJs.put("type", "bar");
			 seriesJs.put("barWidth", 20);
			 seriesJs.put("stack", "年龄");
			 seriesJs.put("data",dataList);
			 seriesArr.add(seriesJs);
		 }
		 JSONObject avgJs = new JSONObject();
		 avgJs.put("name","平均年龄");
		 avgJs.put("type", "line");
		 avgJs.put("smooth", true);	
		 avgJs.put("showAllSymbol", true);
		 avgJs.put("symbol", "emptyCircle");
		 avgJs.put("symbolSize", 15);
		 avgJs.put("yAxisIndex", 1);
		 avgJs.put("data",lineList);
		 seriesArr.add(avgJs); 
		 json.put("xAxis",xAxis);
		 json.put("seriesArr", seriesArr);       
		return json;
	}	
	
	@Override
	public JSONObject findList(String org, String year, String quarter,String month) {
		//System.out.println(0);
		String date = " demissionDate like '"+year+"%' ";
		String dateSql = " (a.inDate <= '"+year+"-12-31') ";
		String demissionSql = " demissionDate >= '"+year+"-01-01' ";

		if(month.equals("0") && quarter.equals("0")){//必选项默认按年查

		}else if(month.equals("0")){//按季度查
			String[] q = {"1","2","3","4"};
			String[] qOutSql={" demissionDate>='"+year+"-01-01' and demissionDate<'"+year+"-04-01' "," demissionDate>='"+year+"-03-01' and demissionDate<'"+year+"-07-01' "," demissionDate>='"+year+"-07-01' and demissionDate<'"+year+"-10-01' "," demissionDate>='"+year+"-10-01' and demissionDate<'"+year+"-12-31' "};
			String[] qInSql={" (a.inDate < '"+year+"-04-01') "," (a.inDate < '"+year+"-07-01') "," (a.inDate < '"+year+"-10-01') "," (a.inDate <= '"+year+"-12-31') "};
			String[] outSql={" demissionDate>='"+year+"-01-01' "," demissionDate>='"+year+"-04-01' "," demissionDate>='"+year+"-07-01' "," demissionDate>='"+year+"-10-01' "};
			
			for(int i=0;i<q.length;i++){
				if(q[i].equals(quarter)){
					date = qOutSql[i];
					dateSql = qInSql[i];
					demissionSql = outSql[i];
					break;
				}
			}			
		}else{//按月查
			month =(month.length()==2 ? month : ("0"+month));
			date=" demissionDate like '"+year+"-"+month+"%' ";
			dateSql = " (a.inDate<'" +year+"-"+month+ "-01' or a.inDate like '" +year+"-"+month+ "%') ";
			demissionSql = " demissionDate >='"+year+"-"+month+"-01' ";
		}
		
		JSONObject json = new JSONObject();
		json.put("chart1", chart1(org, year, quarter, month,date,dateSql));
		json.put("chart2", chart2(org, year, quarter, month,date));
		json.put("chart3", chart3(org, year, quarter, month,dateSql,demissionSql));
		json.put("chart4", chart4(org, year, quarter, month,dateSql,demissionSql));
		// TODO Auto-generated method stub
		//System.out.println(json.toString());
		return json;
	}
	
	
}
