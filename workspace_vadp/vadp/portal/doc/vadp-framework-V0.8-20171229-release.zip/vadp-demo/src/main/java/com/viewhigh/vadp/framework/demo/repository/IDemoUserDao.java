package com.viewhigh.vadp.framework.demo.repository;

import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;

public interface IDemoUserDao {

	public abstract QueryResult getDemoUserByCondition(DemoUser user);

	QueryResult getDemoAllUser();

	public abstract void saveUser(DemoUser user);

}