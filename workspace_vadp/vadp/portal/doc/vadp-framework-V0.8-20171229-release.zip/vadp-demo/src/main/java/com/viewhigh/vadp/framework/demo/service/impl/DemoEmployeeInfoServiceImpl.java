package com.viewhigh.vadp.framework.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.demo.repository.IDemoEmployeeInfoDao;
import com.viewhigh.vadp.framework.demo.service.IDemoEmployeeInfoService;
@Service("EmployeeInfoServiceImpl")
public class DemoEmployeeInfoServiceImpl implements IDemoEmployeeInfoService{
	@Autowired 
	IDemoEmployeeInfoDao empDao;
	@Override
	public List<DemoUser> getAll(){
		return null;
	}
	@Override
	public QueryResult getDemoUserList(String usreId, Integer currentPage,Integer PageNum) {
		QueryResult queryResult=null;
	    if(usreId!=null && !usreId.equals("")){
	    	String hql="from DemoUser where id in (select isMajor from DemoOrg where description=? and position_level=1)";
	    	queryResult= empDao.getDemoUserByPage(hql, new Object[]{usreId},currentPage, PageNum);
	    }
		return queryResult;
	}
	@Override
	public QueryResult findPage() {
		return  empDao.findPage();
	}
	@Override
	public QueryResult getDemoUserListAll(String usreId, Integer currentPage,Integer PageNum) {
		QueryResult queryResult=null;
	    if(usreId!=null && !usreId.equals("")){
	    	queryResult=empDao.getAllUserByPage(new Object[]{usreId}, currentPage, PageNum);
	    }
		return queryResult;
	}
}
