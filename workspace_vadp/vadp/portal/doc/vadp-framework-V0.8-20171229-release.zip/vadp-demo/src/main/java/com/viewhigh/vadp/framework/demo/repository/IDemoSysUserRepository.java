//package com.viewhigh.vadp.framework.demo.repository;
//
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.data.repository.query.Param;
//
//import com.viewhigh.vadp.framework.demo.entity.DemoSysUser;
//public interface IDemoSysUserRepository extends CrudRepository<DemoSysUser, Long>{
//	@Query("select t from DemoSysUser t where t.username=:name")
//	public DemoSysUser findUserByName(@Param("name") String name);
//	
//}
