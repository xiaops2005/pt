package com.viewhigh.vadp.framework.demo.repository.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.repository.DemoDemissionDao;

@Repository
public class DemoDemissionDaoImpl extends BaseHibernateDAO implements DemoDemissionDao{

	@Override
	public List getDemissionById(String id) {
		
		return this.queryObjects("from DemoDemission where id = ?", id);
	
	}

	@Override
	public QueryResult findPage() {
		return this.queryObjectsByPage("from DemoDemission ", null);
	}

	@Override
	public int out(String date, String org) {
		String hql = "select count(*)  from DemoDemission where "+date+" and user.id in (select user.id from DemoCompany where company='"+org+"')";
		 //System.out.println(hql);
		Object obj = this.queryObject(hql);
		int out = Integer.parseInt(obj.toString());
		return out;
	}

	@Override
	public int chart1In(String dateSql, String org) {
		String hql = "select count(*) from DemoUser a where status=1 and "+dateSql+" and id in (select user.id from DemoCompany where company='"+org+"')";
		//System.out.println(hql);
		Object obj = this.queryObject(hql);
		int in = Integer.parseInt(obj.toString());
		return in;
	}

	@Override
	public List chart2List(String date, String org) {
		String chartql = "select causeType,count(*) from DemoDemission where "+date+" and user.id in (select user.id from DemoCompany where company='"+org+"') and causeType<6 group by causeType";
		 //System.out.println(chartql);
		 List list = this.queryObjects(chartql);
		 return list;
	}

	@Override
	public List chart3LegendList(String dateSql, String org,String demissionSql) {//在职状态现在离职 之前是在职，以离职时间计算准确
		String hql = "select distinct b.department from DemoUser a,DemoCompany b where a.id in (select user.id from DemoDemission where "+demissionSql+") and "+dateSql+" and a.id=b.user.id and b.company='"+org+"' group by b.department" ;
		List list = this.queryObjects(hql);
		return list;
	}

	@Override
	public List chart3DataList(int k, String dateSql, String org,String demissionSql) {
		String chartql = "select b.department,count(a.id) from DemoUser a,DemoCompany b where a.id in (select user.id from DemoDemission where "+demissionSql+") and a.education="+k+" and "+dateSql+" and a.id=b.user.id and b.company='"+org+"' group by b.department";
		List list = this.queryObjects(chartql);
		return list;
	}

	@Override
	public List chart4AxisList(String dateSql, String org,String demissionSql) {
		String hql = "select b.department,count(a.id),round(avg(year(now())-year(a.birthdate))) from DemoUser a,DemoCompany b where a.id in (select user.id from DemoDemission where "+demissionSql+") and "+dateSql+" and a.id=b.user.id and b.company='"+org+"' group by b.department" ;
		List list = this.queryObjects(hql);
		return list;
	}

	@Override
	public List chart4DataList(String lSql, String dateSql, String org,String demissionSql) {
		String chartql = "select b.department,count(a.id) from DemoUser a,DemoCompany b where a.id in (select user.id from DemoDemission where "+demissionSql+") and (year(now())-year(a.birthdate)) "+ lSql +" and "+dateSql+" and a.id=b.user.id and b.company='"+org+"' group by b.department";
		List list = this.queryObjects(chartql);
		return list;
	}
	
	
	
	
}
