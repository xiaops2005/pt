package com.viewhigh.vadp.framework.demo.repository;

import java.util.List;

import com.viewhigh.vadp.framework.data.base.dao.IBaseDao;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;

public interface DemoDemissionDao extends IBaseDao {

	public List getDemissionById(String id);
	
	public QueryResult findPage();
	public int out(String date,String org);
	public int chart1In(String dateSql,String org);
	
	public List chart2List(String date,String org);
	public List chart3LegendList(String dateSql,String org,String demissionSql);
	public List chart3DataList(int k,String dateSql,String org,String demissionSql);
	public List chart4AxisList(String dateSql,String org,String demissionSql);
	public List chart4DataList(String lSql,String dateSql,String org,String demissionSql);
	
}
