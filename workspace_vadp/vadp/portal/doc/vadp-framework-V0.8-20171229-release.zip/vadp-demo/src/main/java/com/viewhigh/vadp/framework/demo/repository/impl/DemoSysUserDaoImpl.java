package com.viewhigh.vadp.framework.demo.repository.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.repository.IDemoSysUserDao;

@Repository
public class DemoSysUserDaoImpl extends BaseHibernateDAO implements IDemoSysUserDao {

	@Override
	public List getUserById(Long id) {
		return this.queryObjects("from SysUser where id = ?", id);
	}

	@Override
	public QueryResult findPage() {
		return this.queryObjectsByPage("from SysUser ", null);
	}

	public void save() {
		this.update("insert sys_test values('111')");
	}

}
