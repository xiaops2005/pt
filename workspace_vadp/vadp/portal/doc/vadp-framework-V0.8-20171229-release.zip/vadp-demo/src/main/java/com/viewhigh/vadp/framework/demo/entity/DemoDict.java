package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_dict")
public class DemoDict {
	@Id
	@Column(name="ID")		
    private String id;
	
   @Column(name="table_name")
   private String tableName;
   
   @Column(name="field_name")
   private String fieldName;
   
   @Column(name="field_value")
   private String fieldValue;
   
   @Column(name="field_cn")
   private String fieldCn;
   
   @Column(name="sort")
   private String sort;
   
   @Column(name="remark")
   private String remark;
   

   public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSort() {
		return sort;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getFieldCn() {
		return fieldCn;
	}
	public void setFieldCn(String fieldCn) {
		this.fieldCn = fieldCn;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

   
}
