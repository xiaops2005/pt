package com.viewhigh.vadp.framework.demo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "sys_user")
public class DemoSysUser implements Serializable{

	private Long id;
	private String username;
	private Date birthday;
	private DemoSysRole role;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "username")
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "birthday")
	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = DemoSysRole.class)
	@JoinColumn(name="role_id",nullable=false,updatable=false)
	public DemoSysRole getRole() {
		return role;
	}

	public void setRole(DemoSysRole role) {
		this.role = role;
	}

}
