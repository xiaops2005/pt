package com.viewhigh.vadp.framework.demo.repository;

import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;

public interface IDemoEmployeeInfoDao {
    public QueryResult getDemoUserByPage(final String paramString,final Object[] paramArrayOfObject,final int currentNum, final int pageNum);
    public QueryResult findPage();
    public QueryResult getAllUserByPage(final Object[] paramArrayOfObject,final int currentNum, final int pageNum);
}
