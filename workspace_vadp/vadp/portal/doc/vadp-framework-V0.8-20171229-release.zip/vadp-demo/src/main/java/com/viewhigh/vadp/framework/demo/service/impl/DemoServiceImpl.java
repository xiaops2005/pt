//package com.viewhigh.vadp.framework.demo.service.impl;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//import org.apache.commons.lang.math.RandomUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//import com.google.gson.Gson;
//import com.viewhigh.vadp.framework.demo.entity.DemoSysUser;
//import com.viewhigh.vadp.framework.demo.repository.IDemoSysUserRepository;
//import com.viewhigh.vadp.framework.demo.service.IDemoService;
//
//@Component("demoServiceImpl")
//public class DemoServiceImpl implements IDemoService {
//
//	
//	@Autowired
//	private IDemoSysUserRepository dao;
//	
//	@Value("${name:Hello}")
//	private String name;
//	
//	@Override
//	public String sayHello() {
//		return this.name + " Default !!!";
//	}
//
//	@Override
//	public String sayHello(String userName) {
//		return this.name + "  " + userName + "!!!";
//	}
//
//	@Override
//	public String sayHello(String userName, Integer age) {
//		return this.name + "  " + userName + ">>>" + age + "!!!";
//	}
//
//	@Override
//	public void system() {
//		System.out.println("..................");
//	}
//
//	@Override
//	public String sayHello(Map<String, String> datas, String userName) {
//		return userName + ":" + new Gson().toJson(datas);
//	}
//
//	@Override
//	public String sayHello(DemoSysUser user) {
//		return user + ":" + new Gson().toJson(user);
//	}
//
//	@Override
//	public DemoSysUser getSysUser(Map<String, String> datas, String userName) {
//		return dao.findUserByName(userName);
//	}
//
//	@Override
//	public List<Map<String, String>> sayHello(List<Map<String, String>> list, String userName) {
//		return list;
//	}
//
//	@Override
//	public List<DemoSysUser> sayHello(List<DemoSysUser> users) {
//		return users;
//	}
//
//	@Override
//	public List<String> getIdList(List<Integer> idList) {
//		List<String> list = new ArrayList<String>();
//		for (int i = 0; i < 10; i++) {
//			list.add(RandomUtils.nextInt(10)+"");
//		}
//		return list;
//	}
//
//}
