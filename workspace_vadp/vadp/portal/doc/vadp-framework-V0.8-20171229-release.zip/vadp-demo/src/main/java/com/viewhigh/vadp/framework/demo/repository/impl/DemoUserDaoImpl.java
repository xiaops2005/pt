package com.viewhigh.vadp.framework.demo.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.viewhigh.vadp.framework.data.base.dao.BaseHibernateDAO;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.demo.repository.IDemoUserDao;

/**
 * 
 * 对员工信息进行持久化的类
 * 版权所属：东软望海科技有限公司。
 * 作者：梁国华
 * 版本：V1.0
 * 创建日期：2017年6月5日
 * 修改日期: 2017年6月5日
 */
@Repository
public class DemoUserDaoImpl extends BaseHibernateDAO implements IDemoUserDao {

	/* (non-Javadoc)
	 * @see com.viewhigh.vadp.framework.demo.repository.imp.IDemoUserDao#getDemoUser(java.lang.Object[])
	 */
	@Override
	public QueryResult getDemoUserByCondition(DemoUser user) {
		String sql = "from DemoUser where 1=1";
		List<Object> params = new ArrayList<Object>();
		if (!StringUtils.isEmpty(user.getName())) {
			sql += " and name like ?";
			params.add("%"+user.getName()+"%");
		}
		if (!StringUtils.isEmpty(user.getStatus())) {
			sql += "  and status=?";
			params.add(user.getStatus());
		}
		return this.queryObjectsByPage(sql, params.toArray());
	}

	@Override
	public QueryResult getDemoAllUser() {
		return this.queryObjectsByPage("from DemoUser", null);
	}
	@Override
	public void saveUser(DemoUser user)
	{
		this.addObject(user);
	}
}
