package com.viewhigh.vadp.framework.demo.service;

import java.util.List;

import com.viewhigh.vadp.framework.base.IBaseService;
import com.viewhigh.vadp.framework.demo.entity.DemoReimbDocument;
import com.viewhigh.vadp.framework.demo.entity.DemoReimbDocumentDetail;
import com.viewhigh.vadp.framework.demo.entity.DemoUser;
import com.viewhigh.vadp.framework.ds.BOContext;

/**
 * 
 * 报销单业务类接口
 * 版权所属：东软望海科技有限公司。
 * 作者：刘晓平
 * 版本：V1.0
 * 创建日期：  2017年06月16日
 * 修改日期: 2017年06月16日
 */
public interface IDemoReimbDocumentService extends IBaseService {

	/**
	 * 
	 * @Title: findList   
	 * @Description: 获取报销单列表  
	 * @param: @param title 标题
	 * @param: @return      
	 * @return: List<DemoReimbDocument>      
	 * @throws
	 */
	public List<DemoReimbDocument> findList(String title);
	/**
	 * 
	 * @Title: findByInfo   
	 * @Description: 获取报销单全部信息
	 * @param: @param id
	 * @param: @return      
	 * @return: BOContext      
	 * @throws
	 */
	public BOContext findByInfo(String id);
	/**
	 * 
	 * @Title: findByUserList   
	 * @Description: 获取用户列表
	 * @param: @return      
	 * @return: List<DemoUser>      
	 * @throws
	 */
	public List<DemoUser> findByUserList();
	/**
	 * 
	 * @Title: findDetails   
	 * @Description: 获取报销单详情列表 
	 * @param: @param id
	 * @param: @return      
	 * @return: List<DemoReimbDocumentDetail>      
	 * @throws
	 */
	public List<DemoReimbDocumentDetail> findDetails(String id);
	/**
	 * 
	 * @Title: save   
	 * @Description: 保存报销单   
	 * @param: @param model
	 * @param: @param list
	 * @param: @return      
	 * @return: DemoReimbDocument      
	 * @throws
	 */
	public DemoReimbDocument save(DemoReimbDocument model,List<DemoReimbDocumentDetail> list);
	
}
