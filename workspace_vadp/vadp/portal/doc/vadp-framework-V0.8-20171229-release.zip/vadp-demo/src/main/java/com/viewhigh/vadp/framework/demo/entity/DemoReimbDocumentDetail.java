package com.viewhigh.vadp.framework.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_reimb_document_detail")
public class DemoReimbDocumentDetail {

	
	
		@Id
		@Column(name="ID")		
        private String id;
        
		@Column(name="BILL_CLASSIFICATION")		
        private String billClassification;
        
		@Column(name="REMARK")		
        private String remark;
        
		@Column(name="AMOUNT")		
        private String amount;
        
		@Column(name="BILL_DATE")		
        private String billDate;
		
		@ManyToOne(targetEntity = DemoUser.class)
		@JoinColumn(name = "USER_ID")
		private DemoUser user;
				
		@ManyToOne(targetEntity = DemoReimbDocument.class)		
		@JoinColumn(name = "DOCUMENT_ID")
		private DemoReimbDocument document;
				
				
	    public String getId() {
		 return this.id;
	    }
		public void setId(String id) {
			this.id = id;
		}
		
	    public String getBillClassification() {
		 return this.billClassification;
	    }
		public void setBillClassification(String billClassification) {
			this.billClassification = billClassification;
		}
		
	    public String getRemark() {
		 return this.remark;
	    }
		public void setRemark(String remark) {
			this.remark = remark;
		}
		
	    public String getAmount() {
		 return this.amount;
	    }
		public void setAmount(String amount) {
			this.amount = amount;
		}
		
	    public String getBillDate() {
		 return this.billDate;
	    }
		public void setBillDate(String billDate) {
			this.billDate = billDate;
		}
		
	     public DemoUser getUser() {
		 return this.user;
	    }
		public void setUser(DemoUser user) {
			this.user = user;
		}
	   
	     public DemoReimbDocument getDocument() {
		 return this.document;
	    }
		public void setDocument(DemoReimbDocument document) {
			this.document = document;
		}
	   
}
	