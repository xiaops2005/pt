package com.viewhigh.vadp.framework.demo.service;

import java.util.List;

import com.viewhigh.vadp.framework.base.IBaseService;
import com.viewhigh.vadp.framework.data.persistence.pagination.QueryResult;

public interface IDemoProductService extends IBaseService {
	
	public List getProductById(Long id);

	public QueryResult findPage();
	
	public QueryResult findPageByFilter(String supplier,String standard,String company,String categoryId,String sort,String sortName);
	

}
