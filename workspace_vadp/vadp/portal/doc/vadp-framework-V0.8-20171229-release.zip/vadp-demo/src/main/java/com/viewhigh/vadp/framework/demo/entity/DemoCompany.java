package com.viewhigh.vadp.framework.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/**
 * 
 * 
 * 版权所属：东软望海科技有限公司。
 * 作者：作者
 * 版本：V1.0
 * 创建日期：Apr 16, 2017
 * 修改日期: Apr 16, 2017
 */
@Entity
@Table(name = "demo_company")
public class DemoCompany {
	@Id
	@Column(name="ID")		
    private String id;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Column(name="COMPANY")
	private String company;
	
	@Column(name="DEPARTMENT")
	private String department;
	
	@ManyToOne(targetEntity = DemoUser.class)
	@JoinColumn(name = "USER_ID")
	private DemoUser user;
	
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDepartment() {
		return department;
	}
	public DemoUser getUser() {
		return user;
	}
	public void setUser(DemoUser user) {
		this.user = user;
	}


}
