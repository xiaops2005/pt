//package com.viewhigh.vadp.data;
//
//import org.junit.Test;
//
//import com.viewhigh.vadp.framework.data.conf.ImportResource;
//import com.viewhigh.vadp.framework.data.conf.InitDataSourceConfig;
//@ImportResource(mode="classpath")
//public class Testdata {
//
//	
//	@Test
//	public void test() {
//		new InitDataSourceConfig(Testdata.class); 
//		
//		
//	}
//
//}
